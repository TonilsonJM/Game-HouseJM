# LAN Manager

Sistema de gestão para casas de jogos (PCs, jogos, estoque, vendas, caixa,
usuários/atendentes, auditoria, multiempresa). Este projeto foi extraído de um
protótipo React feito como Claude Artifact e adaptado para rodar como um site
comum, publicável em qualquer serviço de hospedagem.

## Rodar localmente

Pré-requisitos: [Node.js](https://nodejs.org) 18 ou mais recente.

```bash
npm install
npm run dev
```

Abra o endereço mostrado no terminal (normalmente `http://localhost:5173`).

## Publicar na internet (link público)

A forma mais simples é usar a **Vercel** ou a **Netlify** (ambas têm planos
gratuitos):

### Vercel
1. Crie uma conta em https://vercel.com (pode entrar com GitHub).
2. Suba esta pasta para um repositório no GitHub (ou use `vercel` via CLI:
   `npx vercel` dentro da pasta do projeto).
3. Na Vercel, clique em "Add New Project", selecione o repositório.
4. Framework preset: **Vite**. Build command: `npm run build`. Output
   directory: `dist`. Clique em Deploy.
5. Em poucos minutos você recebe um link público (ex:
   `https://lan-manager-seunome.vercel.app`).

### Netlify
1. Crie uma conta em https://netlify.com.
2. Arraste a pasta `dist` (depois de rodar `npm run build`) para o painel de
   deploy manual, **ou** conecte o repositório do GitHub com build command
   `npm run build` e publish directory `dist`.

## Primeiro acesso

- **Super administrador** (painel do dono do sistema): usuário `superadmin`,
  senha `super123`. Troque essa senha assim que possível — não existe tela de
  troca de senha do super admin nesta versão, então se quiser alterá-la, edite
  a constante `DEFAULT_SUPERADMIN_PASSWORD` em `src/App.jsx` antes de publicar,
  ou apague os dados salvos do navegador (isso recria as contas do zero).
- **Casas de jogos / administradores**: cada dono cria a própria conta pela
  tela "Começar gratuitamente" no login.

## Sincronizar entre dispositivos (Supabase)

Por padrão (sem configurar nada) o app guarda tudo em **localStorage**, ou
seja, cada navegador/celular vê seus próprios dados, sem sincronizar. Para
que a mesma casa de jogos veja os mesmos dados em qualquer computador ou
celular, siga estes passos (leva uns 5 minutos, plano gratuito):

1. Crie uma conta em https://supabase.com e crie um novo projeto.
2. Vá em **SQL Editor** (menu lateral) → **New query**, cole o conteúdo do
   arquivo `supabase.sql` (na raiz deste projeto) e clique em **Run**. Isso
   cria a tabela `kv_store` usada pelo app.
3. Vá em **Project Settings → API**. Copie a **Project URL** e a chave
   **anon public**.
4. Na raiz do projeto, copie `.env.example` para `.env` e cole os dois
   valores:
   ```
   VITE_SUPABASE_URL=https://seu-projeto.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anon
   ```
5. Rode `npm run dev` (ou `npm run build`) de novo — o app agora vai ler e
   gravar os dados "compartilhados" (plataforma, casas, backups) direto no
   Supabase. A sessão de login continua salva no aparelho (é assim mesmo,
   cada dispositivo guarda o próprio login).
6. **Se for publicar na Vercel/Netlify**, adicione essas mesmas duas variáveis
   em Project Settings → Environment Variables no painel do serviço, e refaça
   o deploy. Sem isso, o site publicado continuará usando localStorage.

### ⚠️ Sobre segurança dessa configuração

O app tem seu próprio sistema de login (usuário/senha), mas ele roda todo no
navegador — não existe um servidor validando quem pode ler ou escrever no
banco. As políticas em `supabase.sql` deixam a tabela aberta para qualquer um
que tenha a URL e a chave "anon" do seu projeto (essa chave é pública por
natureza, ela aparece no código do site). Ou seja: a separação entre casas de
jogos é garantida pela lógica do app, não por uma trava do banco de dados.

Isso é razoável para um protótipo ou uso interno de confiança, mas **não** é
o nível de segurança que um SaaS real, com dados sensíveis de clientes pagos,
deveria ter. Para isso, o próximo passo seria integrar o **Supabase Auth** e
regras de RLS baseadas em `auth.uid()`, o que exige mudanças mais profundas no
código de login. Posso ajudar com isso se/quando fizer sentido para você.


## Estrutura do projeto

```
lan-manager-app/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── supabase.sql        # script para criar a tabela no Supabase
├── .env.example        # copie para .env com suas credenciais do Supabase
└── src/
    ├── main.jsx        # ponto de entrada, carrega o shim de storage
    ├── storageShim.js  # Supabase (dados compartilhados) + localStorage (sessão)
    ├── index.css       # Tailwind
    └── App.jsx         # todo o sistema (telas, lógica, componentes)
```
