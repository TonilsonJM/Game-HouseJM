# Gerar o APK do LAN Manager (usando o site já publicado na Vercel)

Site publicado: https://vigilant-funicular-virid.vercel.app/

O `capacitor.config.json` já está configurado para abrir esse link dentro do
app Android (modo "WebView apontando pra Vercel"). Você **não precisa**
reconfigurar Supabase de novo — o site publicado já usa as variáveis de
ambiente que você colocou na Vercel.

## Pré-requisitos
- [Node.js](https://nodejs.org) 18+ instalado
- [Android Studio](https://developer.android.com/studio) instalado (com o
  Android SDK configurado — o próprio instalador já baixa)

## Passo a passo

1. Abra um terminal dentro desta pasta (`lan-manager-app`) e instale as
   dependências:
   ```bash
   npm install
   ```

2. Gere a pasta `dist` uma vez (o Capacitor exige que ela exista, mesmo que
   o app não vá usar esses arquivos, já que estamos carregando o site
   remoto pela Vercel):
   ```bash
   npm run build
   ```

3. Adicione a plataforma Android:
   ```bash
   npx cap add android
   ```

4. Sincronize a configuração:
   ```bash
   npx cap sync
   ```

5. Abra o projeto no Android Studio:
   ```bash
   npx cap open android
   ```
   (Isso abre automaticamente o Android Studio com o projeto `android/`
   já criado.)

6. Dentro do Android Studio, espere o Gradle sincronizar (barra de
   progresso embaixo) e depois vá em:
   **Build → Build Bundle(s) / APK(s) → Build APK(s)**

7. Quando terminar, clique em "locate" no aviso que aparece, ou procure em:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```
   Esse é o APK de teste (instala direto no celular via USB ou transferindo
   o arquivo).

## Se quiser trocar o ícone / nome do app
- Nome do app: edite `appName` em `capacitor.config.json` e rode
  `npx cap sync` de novo.
- Ícone: substitua os arquivos em
  `android/app/src/main/res/mipmap-*/ic_launcher.png` (ou use o
  Image Asset Studio do próprio Android Studio: botão direito na pasta
  `res` → New → Image Asset).

## Gerar um APK "de verdade" (assinado, para distribuir)
O `app-debug.apk` funciona para testes, mas não pode ser publicado na Play
Store nem instalado com garantia de atualização. Para isso, no Android
Studio: **Build → Generate Signed Bundle / APK**, crie uma keystore (guarde
em local seguro, ela é necessária pra toda atualização futura) e siga o
assistente escolhendo APK (ou "Android App Bundle" se for publicar na Play
Store).

## Importante sobre esse modelo (app = link remoto)
Como o app carrega `https://vigilant-funicular-virid.vercel.app/` direto da
internet:
- Qualquer atualização que você fizer no site (novo deploy na Vercel)
  aparece automaticamente no app, sem precisar gerar um novo APK.
- O app **exige internet** para funcionar (não tem modo totalmente offline).
- Se quiser um app que funcione com os arquivos empacotados dentro do APK
  (sem depender de internet para carregar a interface, só para os dados do
  Supabase), é só remover o bloco `"server"` do `capacitor.config.json` —
  mas aí você precisa rodar `npm run build` + `npx cap sync` toda vez que
  atualizar o app.
