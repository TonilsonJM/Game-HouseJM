import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Monitor, Gamepad2, Clock, BarChart3, Wallet, Layers, LayoutDashboard,
  Plus, Trash2, Search, Download, Users, TrendingUp, Package,
  CalendarClock, X, Check, Pencil, PlusCircle, ChevronDown, ChevronUp,
  AlertTriangle, Zap, ArrowRightCircle, RotateCcw, Square, CircleDot,
  ShoppingCart, PackageX, Boxes, SlidersHorizontal, ClipboardList, Tag,
  Bell, LogOut, ShieldCheck, ShieldAlert, KeyRound, Database, UploadCloud,
  DownloadCloud, Lock, Unlock, UserCog, Eye, EyeOff, UserPlus, Timer,
  BadgeCheck, BadgeX, Fingerprint
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

/* ---------------------------------------------------------------------- */
/* Constantes                                                              */
/* ---------------------------------------------------------------------- */

const DEFAULT_GAMES = [
  { id: "g1", name: "GTA V", category: "Ação", icon: "🚗", prices: [
    { id: "p1", label: "30 min", minutes: 30, value: 250 },
    { id: "p2", label: "1 hora", minutes: 60, value: 450 },
  ]},
  { id: "g2", name: "FC 26", category: "Esporte", icon: "⚽", prices: [
    { id: "p3", label: "30 min", minutes: 30, value: 200 },
    { id: "p4", label: "1 hora", minutes: 60, value: 350 },
  ]},
  { id: "g3", name: "Free Fire", category: "Battle Royale", icon: "🔥", prices: [
    { id: "p5", label: "15 min", minutes: 15, value: 100 },
    { id: "p6", label: "30 min", minutes: 30, value: 180 },
  ]},
  { id: "g4", name: "Valorant", category: "FPS", icon: "🎯", prices: [
    { id: "p7", label: "30 min", minutes: 30, value: 250 },
    { id: "p8", label: "1 hora", minutes: 60, value: 450 },
  ]},
  { id: "g5", name: "Mortal Kombat", category: "Luta", icon: "🥋", prices: [
    { id: "p9", label: "1 batalha", minutes: 10, value: 50 },
  ]},
];

const STATUS_META = {
  livre:      { label: "Livre",      dot: "bg-emerald-400", text: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/30" },
  ocupado:    { label: "Ocupado",    dot: "bg-amber-400",   text: "text-amber-400",   bg: "bg-amber-500/10",   border: "border-amber-500/30" },
  reservado:  { label: "Reservado",  dot: "bg-violet-400",  text: "text-violet-400",  bg: "bg-violet-500/10",  border: "border-violet-500/30" },
  manutencao: { label: "Manutenção", dot: "bg-zinc-400",    text: "text-zinc-400",    bg: "bg-zinc-500/10",    border: "border-zinc-500/30" },
};

const EXPENSE_CATEGORIES = ["Energia", "Manutenção", "Internet", "Limpeza", "Outros"];
const PRODUCT_CATEGORIES = ["Bebida", "Snack", "Doce", "Acessório", "Outros"];
const ROLE_LABELS = { admin: "Administrador", atendente: "Atendente", superadmin: "Super Administrador" };
const INACTIVITY_LIMIT_MS = 20 * 60 * 1000; // 20 minutos
const DEFAULT_SUPERADMIN_USERNAME = "superadmin";
const DEFAULT_SUPERADMIN_PASSWORD = "super123";
const PLAN_LABEL = "Gratuito";

const ADMIN_TABS = [
  { key: "painel", label: "Painel", icon: LayoutDashboard },
  { key: "pcs", label: "PCs", icon: Monitor },
  { key: "sessao", label: "Sessão", icon: Gamepad2 },
  { key: "historico", label: "Histórico", icon: Clock },
  { key: "relatorios", label: "Relatórios", icon: BarChart3 },
  { key: "caixa", label: "Aprovações", icon: Wallet },
  { key: "mais", label: "Mais", icon: Layers },
];
const ATENDENTE_TABS = [
  { key: "painel", label: "Painel", icon: LayoutDashboard },
  { key: "pcs", label: "PCs", icon: Monitor },
  { key: "sessao", label: "Sessão", icon: Gamepad2 },
  { key: "historico", label: "Histórico", icon: Clock },
  { key: "caixa", label: "Meu caixa", icon: Wallet },
  { key: "mais", label: "Mais", icon: Layers },
];

const ADMIN_MAIS_SECTIONS = [
  { key: "usuarios", label: "Usuários", icon: UserCog },
  { key: "jogos", label: "Jogos e preços", icon: Gamepad2 },
  { key: "produtos", label: "Produtos", icon: Package },
  { key: "vendas", label: "Vendas", icon: ClipboardList },
  { key: "reservas", label: "Reservas", icon: CalendarClock },
  { key: "atendentes", label: "Relatório atendentes", icon: BarChart3 },
  { key: "auditoria", label: "Auditoria", icon: ShieldCheck },
  { key: "notificacoes", label: "Notificações", icon: Bell },
  { key: "backup", label: "Backup", icon: Database },
];
const ATENDENTE_MAIS_SECTIONS = [
  { key: "venda", label: "Nova venda", icon: ShoppingCart },
  { key: "vendas", label: "Minhas vendas", icon: ClipboardList },
  { key: "estoque", label: "Consultar estoque", icon: Package },
  { key: "reservas", label: "Reservas", icon: CalendarClock },
];

/* ---------------------------------------------------------------------- */
/* Helpers                                                                  */
/* ---------------------------------------------------------------------- */

const genId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

const fmtKz = (v) => `${Number(v || 0).toLocaleString("pt-AO")} Kz`;

const fmtCountdown = (totalSeconds) => {
  const s = Math.max(0, Math.round(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
};

const fmtDateTime = (ts) => ts ? new Date(ts).toLocaleString("pt-AO", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—";
const fmtTime = (ts) => ts ? new Date(ts).toLocaleTimeString("pt-AO", { hour: "2-digit", minute: "2-digit" }) : "—";

function inPeriod(ts, period, range) {
  const d = new Date(ts);
  const now = new Date();
  if (period === "hoje") return d.toDateString() === now.toDateString();
  if (period === "ontem") {
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    return d.toDateString() === yesterday.toDateString();
  }
  if (period === "semana") {
    const weekAgo = new Date(now);
    weekAgo.setDate(now.getDate() - 6);
    weekAgo.setHours(0, 0, 0, 0);
    return d >= weekAgo && d <= now;
  }
  if (period === "mes") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  if (period === "ano") return d.getFullYear() === now.getFullYear();
  if (period === "custom" && range && range.start && range.end) {
    const start = new Date(range.start); start.setHours(0, 0, 0, 0);
    const end = new Date(range.end); end.setHours(23, 59, 59, 999);
    return d >= start && d <= end;
  }
  return true;
}

function playBeep(kind) {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const tone = (freq, start, dur) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "square";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.16, ctx.currentTime + start + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.02);
    };
    if (kind === "warn") tone(660, 0, 0.16);
    else if (kind === "urgent") { tone(880, 0, 0.15); tone(880, 0.22, 0.15); }
    else if (kind === "alarm") { tone(1046, 0, 0.15); tone(1046, 0.22, 0.15); tone(1046, 0.44, 0.28); }
    else if (kind === "notif") tone(1200, 0, 0.09);
    setTimeout(() => ctx.close(), 1400);
  } catch (e) { /* audio indisponível */ }
}

async function hashPassword(pw) {
  try {
    const enc = new TextEncoder().encode(String(pw));
    const buf = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch (e) {
    let h = 0;
    const s = String(pw);
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return `fallback-${h}`;
  }
}

function generateRecoveryCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 10; i++) {
    if (i === 5) code += "-";
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

function getDeviceInfo() {
  try {
    const ua = navigator.userAgent || "";
    let os = "Desconhecido";
    if (/Windows/i.test(ua)) os = "Windows";
    else if (/Mac OS/i.test(ua)) os = "macOS";
    else if (/Android/i.test(ua)) os = "Android";
    else if (/iPhone|iPad/i.test(ua)) os = "iOS";
    else if (/Linux/i.test(ua)) os = "Linux";
    let browser = "Navegador";
    if (/Edg/i.test(ua)) browser = "Edge";
    else if (/Chrome/i.test(ua)) browser = "Chrome";
    else if (/Firefox/i.test(ua)) browser = "Firefox";
    else if (/Safari/i.test(ua)) browser = "Safari";
    return `${browser} · ${os}`;
  } catch (e) { return "Dispositivo desconhecido"; }
}

function initialDb() {
  return {
    pcs: Array.from({ length: 8 }, (_, i) => ({
      id: genId(), number: i + 1, name: `PC ${String(i + 1).padStart(2, "0")}`,
      status: "livre", session: null,
    })),
    games: DEFAULT_GAMES,
    history: [],
    expenses: [],
    products: [],
    stockMovements: [],
    sales: [],
    reservations: [],
    auditLog: [],
    notifications: [],
    cashRegisters: [],
    lastBackupDate: null,
  };
}

function computeAttendantStats(db, users, periodPredicate) {
  const atendentes = (users || []).filter((u) => u.role === "atendente");
  return atendentes.map((u) => {
    const games = db.history.filter((h) => h.userId === u.id && h.type === "inicio" && periodPredicate(h.timestamp));
    const renovs = db.history.filter((h) => h.userId === u.id && h.type === "renovacao" && periodPredicate(h.timestamp));
    const sales = (db.sales || []).filter((s) => s.userId === u.id && !s.cancelled && periodPredicate(s.timestamp));
    const cancelled = (db.sales || []).filter((s) => s.userId === u.id && s.cancelled && periodPredicate(s.timestamp));
    const revenueGames = [...games, ...renovs].reduce((sum, h) => sum + h.value, 0);
    const revenueSales = sales.reduce((sum, s) => sum + s.totalValue, 0);
    const avgMinutes = games.length ? games.reduce((s, h) => s + (h.minutes || 0), 0) / games.length : 0;
    const productsQty = sales.reduce((s, x) => s + x.qty, 0);
    const regs = (db.cashRegisters || []).filter((c) => c.userId === u.id && periodPredicate(c.openTime)).sort((a, b) => b.openTime - a.openTime);
    const lastReg = regs[0];
    const logins = db.auditLog.filter((a) => a.userId === u.id && a.action === "Fez login" && periodPredicate(a.timestamp)).sort((a, b) => a.timestamp - b.timestamp);
    const logouts = db.auditLog.filter((a) => a.userId === u.id && (a.action === "Fez logout" || a.action.startsWith("Logout automático")) && periodPredicate(a.timestamp)).sort((a, b) => b.timestamp - a.timestamp);
    return {
      user: u,
      jogos: games.length + renovs.length,
      produtos: productsQty,
      receita: revenueGames + revenueSales,
      cancelamentos: cancelled.length,
      tempoMedio: avgMinutes,
      entrada: lastReg ? lastReg.openTime : (logins[0] ? logins[0].timestamp : null),
      saida: lastReg ? lastReg.closeTime : (logouts[0] ? logouts[0].timestamp : null),
    };
  });
}

/* ---------------------------------------------------------------------- */
/* Átomos de UI                                                             */
/* ---------------------------------------------------------------------- */

function StatCard({ label, value, icon: Icon, accent = "text-slate-100", className = "" }) {
  return (
    <div className={`bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-col gap-1 ${className}`}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] uppercase tracking-wider text-slate-500">{label}</span>
        {Icon && <Icon size={14} className="text-slate-600" />}
      </div>
      <span className={`text-2xl font-mono font-semibold ${accent}`}>{value}</span>
    </div>
  );
}

function StatusPill({ status }) {
  const meta = STATUS_META[status];
  return (
    <span className={`inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-1 rounded-full border ${meta.bg} ${meta.border} ${meta.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${meta.dot}`} />
      {meta.label}
    </span>
  );
}

function RolePill({ role }) {
  const isAdmin = role === "admin";
  return (
    <span className={`inline-flex items-center gap-1.5 text-[10px] font-medium px-2 py-0.5 rounded-full border ${isAdmin ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-400" : "bg-slate-700/40 border-slate-600 text-slate-300"}`}>
      {isAdmin ? <ShieldCheck size={11} /> : <Fingerprint size={11} />}
      {ROLE_LABELS[role] || role}
    </span>
  );
}

function SectionHeader({ title, subtitle, right }) {
  return (
    <div className="flex items-end justify-between mb-3 gap-2">
      <div>
        <h2 className="text-lg font-semibold text-slate-100 tracking-tight">{title}</h2>
        {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="border border-dashed border-slate-800 rounded-2xl p-6 text-center text-sm text-slate-500">
      {text}
    </div>
  );
}

function PrimaryButton({ children, onClick, className = "", disabled, type = "button" }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-700 disabled:text-slate-500 text-slate-950 font-semibold rounded-xl px-4 py-2.5 text-sm transition-colors ${className}`}
    >
      {children}
    </button>
  );
}

function GhostButton({ children, onClick, className = "", disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 font-medium rounded-xl px-3 py-2 text-xs transition-colors ${className}`}
    >
      {children}
    </button>
  );
}

function TextInput(props) {
  return (
    <input
      {...props}
      className={`bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-600 w-full ${props.className || ""}`}
    />
  );
}

function Select(props) {
  return (
    <select
      {...props}
      className={`bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none rounded-lg px-3 py-2 text-sm text-slate-100 w-full ${props.className || ""}`}
    />
  );
}

function Banner({ tone = "amber", icon: Icon = AlertTriangle, children }) {
  const map = {
    amber: "bg-amber-500/10 border-amber-500/30 text-amber-400",
    red: "bg-red-500/10 border-red-500/30 text-red-400",
    cyan: "bg-cyan-500/10 border-cyan-500/30 text-cyan-400",
  };
  return (
    <div className={`flex items-start gap-2 border rounded-xl px-3 py-2.5 text-xs ${map[tone]}`}>
      <Icon size={15} className="mt-0.5 shrink-0" />
      <div>{children}</div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Login                                                                    */
/* ---------------------------------------------------------------------- */

function AuthShell({ children, subtitle }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6" style={{ fontFamily: "'Inter', ui-sans-serif, system-ui" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap');`}</style>
      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-2">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
            <Gamepad2 size={22} className="text-cyan-400" />
          </div>
          <span className="font-semibold tracking-tight text-lg">LAN Manager</span>
          <span className="text-xs text-slate-500">{subtitle}</span>
        </div>
        {children}
      </div>
    </div>
  );
}

function LoginForm({ platform, onLogin, goSignup, goForgot }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError("");
    if (!username.trim() || !password) { setError("Preencha usuário e senha."); return; }
    const u = platform.accounts.find((x) => x.username.toLowerCase() === username.trim().toLowerCase());
    if (!u) { setError("Usuário não encontrado."); return; }
    if (!u.active) { setError("Este usuário está bloqueado. Contate o administrador ou o suporte."); return; }
    if (u.role !== "superadmin") {
      const tenant = platform.tenants.find((t) => t.id === u.tenantId);
      if (!tenant || !tenant.active) { setError("Esta casa de jogos está desativada. Contate o suporte."); return; }
    }
    setBusy(true);
    const hash = await hashPassword(password);
    setBusy(false);
    if (hash !== u.passwordHash) { setError("Senha incorreta."); return; }
    onLogin(u);
  };

  return (
    <>
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Usuário</label>
          <TextInput placeholder="ex: joao01" value={username} onChange={(e) => setUsername(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} autoFocus />
        </div>
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Senha</label>
          <div className="relative">
            <TextInput type={showPw ? "text" : "password"} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} className="pr-9" />
            <button type="button" onClick={() => setShowPw((s) => !s)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500">
              {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>
        </div>
        {error && <Banner tone="red" icon={ShieldAlert}>{error}</Banner>}
        <PrimaryButton onClick={submit} disabled={busy} className="w-full flex items-center justify-center gap-2">
          <KeyRound size={15} /> {busy ? "Verificando…" : "Entrar"}
        </PrimaryButton>
        <button onClick={goForgot} className="text-[11px] text-slate-500 w-full text-center">Esqueci minha senha</button>
      </div>
      <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-2xl p-4 text-center space-y-2">
        <p className="text-xs text-slate-500">É dono de uma casa de jogos e ainda não tem conta?</p>
        <PrimaryButton onClick={goSignup} className="w-full flex items-center justify-center gap-2">
          <UserPlus size={15} /> Começar gratuitamente
        </PrimaryButton>
      </div>
      <p className="text-center text-[11px] text-slate-600">Acesso protegido por login. Sessões expiram após inatividade.</p>
    </>
  );
}

function SignupForm({ platform, onSignup, goLogin }) {
  const [form, setForm] = useState({ adminName: "", venueName: "", phone: "", username: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [recoveryCode, setRecoveryCode] = useState(null);

  const submit = async () => {
    setError("");
    const { adminName, venueName, phone, username, password, confirm } = form;
    if (!adminName.trim() || !venueName.trim() || !phone.trim() || !username.trim() || !password || !confirm) { setError("Preencha todos os campos."); return; }
    if (password.length < 6) { setError("A senha deve ter pelo menos 6 caracteres."); return; }
    if (password !== confirm) { setError("As senhas não coincidem."); return; }
    if (platform.accounts.some((a) => a.username.toLowerCase() === username.trim().toLowerCase())) { setError("Este usuário já está em uso. Escolha outro."); return; }
    setBusy(true);
    const code = await onSignup({ adminName: adminName.trim(), venueName: venueName.trim(), phone: phone.trim(), username: username.trim(), password });
    setBusy(false);
    setRecoveryCode(code);
  };

  if (recoveryCode) {
    return (
      <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-4 space-y-3">
        <Banner tone="cyan" icon={ShieldCheck}>Conta criada! Guarde o código de recuperação abaixo — ele é a única forma de redefinir sua senha caso a esqueça. Ele não será mostrado novamente.</Banner>
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-center font-mono text-lg tracking-widest text-cyan-400">{recoveryCode}</div>
        <PrimaryButton onClick={goLogin} className="w-full">Ir para o login</PrimaryButton>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
      <div className="text-sm font-medium text-slate-200">Criar conta de administrador</div>
      <TextInput placeholder="Nome do administrador" value={form.adminName} onChange={(e) => setForm((f) => ({ ...f, adminName: e.target.value }))} />
      <TextInput placeholder="Nome da casa de jogos" value={form.venueName} onChange={(e) => setForm((f) => ({ ...f, venueName: e.target.value }))} />
      <TextInput placeholder="Telefone" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
      <TextInput placeholder="Usuário (login)" value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} />
      <TextInput type="password" placeholder="Senha (mín. 6 caracteres)" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
      <TextInput type="password" placeholder="Confirmar senha" value={form.confirm} onChange={(e) => setForm((f) => ({ ...f, confirm: e.target.value }))} />
      {error && <Banner tone="red" icon={ShieldAlert}>{error}</Banner>}
      <PrimaryButton onClick={submit} disabled={busy} className="w-full">{busy ? "Criando…" : "Criar minha conta grátis"}</PrimaryButton>
      <button onClick={goLogin} className="text-[11px] text-slate-500 w-full text-center">Já tenho conta — voltar ao login</button>
    </div>
  );
}

function ForgotForm({ onForgotSubmit, goLogin }) {
  const [username, setUsername] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(""); setSuccess("");
    if (!username.trim() || !code.trim() || !password || !confirm) { setError("Preencha todos os campos."); return; }
    if (password.length < 6) { setError("A senha deve ter pelo menos 6 caracteres."); return; }
    if (password !== confirm) { setError("As senhas não coincidem."); return; }
    setBusy(true);
    const ok = await onForgotSubmit(username.trim(), code.trim(), password);
    setBusy(false);
    if (ok) setSuccess("Senha redefinida com sucesso. Você já pode entrar.");
    else setError("Usuário ou código de recuperação inválidos.");
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
      <div className="text-sm font-medium text-slate-200">Recuperar senha (contas de administrador)</div>
      <TextInput placeholder="Usuário" value={username} onChange={(e) => setUsername(e.target.value)} />
      <TextInput placeholder="Código de recuperação" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} />
      <TextInput type="password" placeholder="Nova senha" value={password} onChange={(e) => setPassword(e.target.value)} />
      <TextInput type="password" placeholder="Confirmar nova senha" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      {error && <Banner tone="red" icon={ShieldAlert}>{error}</Banner>}
      {success && <Banner tone="cyan" icon={ShieldCheck}>{success}</Banner>}
      <PrimaryButton onClick={submit} disabled={busy} className="w-full">{busy ? "Verificando…" : "Redefinir senha"}</PrimaryButton>
      <button onClick={goLogin} className="text-[11px] text-slate-500 w-full text-center">Voltar ao login</button>
      <p className="text-[10px] text-slate-600">Atendentes não têm código de recuperação — peça ao administrador da sua casa para redefinir sua senha em Mais → Usuários.</p>
    </div>
  );
}

function AuthScreen({ platform, onLogin, onSignup, onForgotSubmit }) {
  const [mode, setMode] = useState("login");
  const subtitle = mode === "login" ? "Faça login para continuar" : mode === "signup" ? "Crie sua conta gratuitamente" : "Recuperação de senha";
  return (
    <AuthShell subtitle={subtitle}>
      {mode === "login" && <LoginForm platform={platform} onLogin={onLogin} goSignup={() => setMode("signup")} goForgot={() => setMode("forgot")} />}
      {mode === "signup" && <SignupForm platform={platform} onSignup={onSignup} goLogin={() => setMode("login")} />}
      {mode === "forgot" && <ForgotForm onForgotSubmit={onForgotSubmit} goLogin={() => setMode("login")} />}
    </AuthShell>
  );
}

/* ---------------------------------------------------------------------- */
/* Painel                                                                   */
/* ---------------------------------------------------------------------- */

function PainelView({ db, tick, goToSessao, ctx }) {
  const now = Date.now();
  const totalPcs = db.pcs.length;
  const livres = db.pcs.filter((p) => p.status === "livre").length;
  const ocupados = db.pcs.filter((p) => p.status === "ocupado").length;
  const ocupadosList = db.pcs.filter((p) => p.status === "ocupado" && p.session);

  if (!ctx.isAdmin) {
    const historyToday = db.history.filter((h) => h.userId === ctx.currentUser.id && inPeriod(h.timestamp, "hoje"));
    const salesToday = (db.sales || []).filter((s) => s.userId === ctx.currentUser.id && !s.cancelled && inPeriod(s.timestamp, "hoje"));
    const meusJogosHoje = historyToday.filter((h) => h.type === "inicio").length;
    const minhaReceitaHoje = historyToday.reduce((s, h) => s + h.value, 0) + salesToday.reduce((s, x) => s + x.totalValue, 0);
    const lowStock = (db.products || []).filter((p) => p.status === "ativo" && p.qty > 0 && p.qty <= Number(p.minStock || 0)).length;
    const outStock = (db.products || []).filter((p) => p.status === "ativo" && p.qty <= 0).length;
    const myCaixa = (db.cashRegisters || []).find((c) => c.userId === ctx.currentUser.id && c.status === "aberto");

    return (
      <div className="p-4 space-y-5">
        <SectionHeader title="Painel" subtitle={new Date().toLocaleDateString("pt-AO", { weekday: "long", day: "2-digit", month: "long" })} />
        {!myCaixa && (
          <Banner tone="amber">Você ainda não abriu o caixa hoje. Abra em <b>Meu caixa</b> antes de iniciar sessões ou vendas.</Banner>
        )}
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="PCs livres" value={livres} icon={CircleDot} accent="text-emerald-400" />
          <StatCard label="PCs ocupados" value={ocupados} icon={Monitor} accent="text-amber-400" />
          <StatCard label="Seus jogos hoje" value={meusJogosHoje} icon={Gamepad2} />
          <StatCard label="Sua receita hoje" value={fmtKz(minhaReceitaHoje)} icon={TrendingUp} accent="text-cyan-400" />
        </div>
        {(lowStock > 0 || outStock > 0) && (
          <Banner tone="amber" icon={AlertTriangle}>
            {outStock > 0 && <span>{outStock} produto(s) esgotado(s). </span>}
            {lowStock > 0 && <span>{lowStock} produto(s) com estoque baixo.</span>}
          </Banner>
        )}
        <div>
          <SectionHeader title="PCs disponíveis" />
          <div className="grid grid-cols-4 gap-2">
            {db.pcs.sort((a, b) => a.number - b.number).map((pc) => (
              <div key={pc.id} className={`rounded-xl border p-2 text-center ${STATUS_META[pc.status].bg} ${STATUS_META[pc.status].border}`}>
                <div className="text-[11px] font-medium text-slate-200">{pc.name}</div>
                <div className={`text-[10px] ${STATUS_META[pc.status].text}`}>{STATUS_META[pc.status].label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const historyToday = db.history.filter((h) => inPeriod(h.timestamp, "hoje"));
  const jogosHoje = historyToday.filter((h) => h.type === "inicio").length;
  const clientesHoje = new Set(historyToday.filter((h) => h.client && h.client.trim()).map((h) => h.client.trim().toLowerCase())).size;
  const receitaJogosHoje = historyToday.reduce((sum, h) => sum + h.value, 0);

  const salesToday = (db.sales || []).filter((s) => !s.cancelled && inPeriod(s.timestamp, "hoje"));
  const receitaVendasHoje = salesToday.reduce((sum, s) => sum + s.totalValue, 0);
  const produtosVendidosHoje = salesToday.reduce((sum, s) => sum + s.qty, 0);
  const receitaTotalHoje = receitaJogosHoje + receitaVendasHoje;

  const vendasPorProduto = {};
  salesToday.forEach((s) => { vendasPorProduto[s.productName] = (vendasPorProduto[s.productName] || 0) + s.qty; });
  let produtoMaisVendido = "—", maiorQtd = 0;
  Object.entries(vendasPorProduto).forEach(([name, qty]) => { if (qty > maiorQtd) { produtoMaisVendido = name; maiorQtd = qty; } });

  const products = db.products || [];
  const lowStock = products.filter((p) => p.status === "ativo" && p.qty > 0 && p.qty <= Number(p.minStock || 0));
  const outStock = products.filter((p) => p.status === "ativo" && p.qty <= 0);

  const attendantStats = computeAttendantStats(db, ctx.tenantUsers, (ts) => inPeriod(ts, "hoje"));
  const pendingCash = (db.cashRegisters || []).filter((c) => c.status === "fechado");
  const unreadNotifs = (db.notifications || []).filter((n) => !n.read).length;

  return (
    <div className="p-4 space-y-5">
      <SectionHeader title="Painel" subtitle={new Date().toLocaleDateString("pt-AO", { weekday: "long", day: "2-digit", month: "long" })} />

      {unreadNotifs > 0 && (
        <Banner tone="cyan" icon={Bell}>{unreadNotifs} notificação(ões) não lida(s). Veja em Mais → Notificações.</Banner>
      )}
      {pendingCash.length > 0 && (
        <Banner tone="amber" icon={Wallet}>{pendingCash.length} fechamento(s) de caixa aguardando aprovação.</Banner>
      )}

      <div className="grid grid-cols-2 gap-3">
        <StatCard label="PCs no total" value={totalPcs} icon={Monitor} />
        <StatCard label="Livres / Ocupados" value={`${livres} / ${ocupados}`} icon={CircleDot} accent="text-emerald-400" />
        <StatCard label="Clientes hoje" value={clientesHoje} icon={Users} />
        <StatCard label="Jogos hoje" value={jogosHoje} icon={Gamepad2} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Receita dos jogos" value={fmtKz(receitaJogosHoje)} icon={Gamepad2} accent="text-cyan-400" />
        <StatCard label="Receita do estoque" value={fmtKz(receitaVendasHoje)} icon={ShoppingCart} accent="text-violet-400" />
        <StatCard label="Receita total" value={fmtKz(receitaTotalHoje)} icon={TrendingUp} accent="text-emerald-400" className="col-span-2" />
        <StatCard label="Produtos vendidos hoje" value={produtosVendidosHoje} icon={Boxes} />
        <StatCard label="Produto mais vendido" value={produtoMaisVendido} icon={Tag} />
      </div>

      {(lowStock.length > 0 || outStock.length > 0) && (
        <div className="space-y-2">
          <SectionHeader title="Alertas de estoque" />
          {outStock.map((p) => (
            <div key={p.id} className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2 text-sm text-red-400">
              <PackageX size={15} /> <span className="font-medium">{p.name}</span> — esgotado
            </div>
          ))}
          {lowStock.map((p) => (
            <div key={p.id} className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2 text-sm text-amber-400">
              <AlertTriangle size={15} /> <span className="font-medium">{p.name}</span> — estoque baixo ({p.qty} un.)
            </div>
          ))}
        </div>
      )}

      <div>
        <SectionHeader title="Monitoramento em tempo real" subtitle="Desempenho dos atendentes hoje" />
        {attendantStats.length === 0 ? (
          <EmptyState text="Nenhum atendente cadastrado ainda." />
        ) : (
          <div className="space-y-2">
            {attendantStats.map((a) => (
              <div key={a.user.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-100 flex items-center gap-1.5">{a.user.name}{!a.user.active && <span className="text-[10px] text-red-400">(bloqueado)</span>}</div>
                  <div className="text-xs text-slate-500">{a.jogos} jogo(s) · {a.produtos} produto(s) vendido(s)</div>
                </div>
                <div className="font-mono text-sm font-semibold text-emerald-400">{fmtKz(a.receita)}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <SectionHeader title="Em andamento" subtitle={`${ocupadosList.length} PC(s) ocupados agora`} />
        {ocupadosList.length === 0 ? (
          <EmptyState text="Nenhum PC ocupado no momento." />
        ) : (
          <div className="space-y-2">
            {ocupadosList.map((pc) => {
              const remaining = Math.round((pc.session.endTime - now) / 1000);
              const expired = remaining <= 0;
              const color = expired ? "text-red-400" : remaining <= 300 ? "text-amber-400" : "text-slate-100";
              return (
                <button
                  key={pc.id}
                  onClick={goToSessao}
                  className="w-full flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-left active:scale-[0.99] transition-transform"
                >
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-slate-100">{pc.name}</span>
                    <span className="text-xs text-slate-500">{pc.session.gameName} · {pc.session.client || "Cliente sem nome"}</span>
                    <span className="text-[11px] text-cyan-400">Atendente: {pc.session.userName || "—"}</span>
                  </div>
                  <span className={`font-mono text-lg font-semibold ${color} ${expired ? "animate-pulse" : ""}`}>
                    {expired ? "00:00" : fmtCountdown(remaining)}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Gestão de PCs                                                           */
/* ---------------------------------------------------------------------- */

function PcsView({ db, setDb, ctx }) {
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");

  const addPc = () => {
    const nextNumber = db.pcs.length ? Math.max(...db.pcs.map((p) => p.number)) + 1 : 1;
    const name = newName.trim() || `PC ${String(nextNumber).padStart(2, "0")}`;
    const pc = { id: genId(), number: nextNumber, name, status: "livre", session: null };
    setDb((prev) => ({ ...prev, pcs: [...prev.pcs, pc] }));
    ctx.audit("Adicionou PC", { pcName: name });
    setNewName("");
  };

  const removePc = (id) => {
    const pc = db.pcs.find((p) => p.id === id);
    setDb((prev) => ({ ...prev, pcs: prev.pcs.filter((p) => p.id !== id) }));
    ctx.audit("Excluiu PC", { pcName: pc?.name });
  };

  const saveEdit = (id) => {
    const oldPc = db.pcs.find((p) => p.id === id);
    setDb((prev) => ({ ...prev, pcs: prev.pcs.map((p) => (p.id === id ? { ...p, name: editName.trim() || p.name } : p)) }));
    ctx.audit("Editou cadastro", { pcName: `${oldPc?.name} → ${editName.trim() || oldPc?.name}` });
    setEditingId(null);
  };

  const setStatus = (id, status) => {
    const pc = db.pcs.find((p) => p.id === id);
    setDb((prev) => ({ ...prev, pcs: prev.pcs.map((p) => (p.id === id ? { ...p, status } : p)) }));
    ctx.audit("Alterou status do PC", { pcName: pc?.name, action: STATUS_META[status].label });
  };

  if (!ctx.isAdmin) {
    return (
      <div className="p-4 space-y-4">
        <SectionHeader title="Disponibilidade dos PCs" subtitle={`${db.pcs.length} computador(es)`} />
        <div className="grid grid-cols-2 gap-2">
          {db.pcs.sort((a, b) => a.number - b.number).map((pc) => (
            <div key={pc.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col gap-1.5">
              <span className="font-medium text-slate-100 text-sm">{pc.name}</span>
              <StatusPill status={pc.status} />
              {pc.session && <span className="text-[11px] text-slate-500">{pc.session.gameName}</span>}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <SectionHeader title="Gestão de PCs" subtitle={`${db.pcs.length} computador(es) cadastrados`} />

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex gap-2">
        <TextInput placeholder="Nome personalizado (opcional)" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <PrimaryButton onClick={addPc} className="whitespace-nowrap flex items-center gap-1"><Plus size={16} /> Add PC</PrimaryButton>
      </div>

      <div className="space-y-2">
        {db.pcs.sort((a, b) => a.number - b.number).map((pc) => (
          <div key={pc.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              {editingId === pc.id ? (
                <div className="flex gap-2 flex-1 mr-2">
                  <TextInput value={editName} onChange={(e) => setEditName(e.target.value)} autoFocus />
                  <button onClick={() => saveEdit(pc.id)} className="text-emerald-400"><Check size={20} /></button>
                  <button onClick={() => setEditingId(null)} className="text-slate-500"><X size={20} /></button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-100">{pc.name}</span>
                  <button onClick={() => { setEditingId(pc.id); setEditName(pc.name); }} className="text-slate-600"><Pencil size={13} /></button>
                </div>
              )}
              <StatusPill status={pc.status} />
            </div>
            <div className="flex items-center justify-between gap-2">
              <div className="flex gap-1.5 flex-wrap">
                {["livre", "reservado", "manutencao"].map((s) => (
                  <button
                    key={s}
                    disabled={pc.status === "ocupado"}
                    onClick={() => setStatus(pc.id, s)}
                    className={`text-[11px] px-2 py-1 rounded-lg border ${pc.status === s ? `${STATUS_META[s].bg} ${STATUS_META[s].border} ${STATUS_META[s].text}` : "border-slate-800 text-slate-500"} disabled:opacity-30`}
                  >
                    {STATUS_META[s].label}
                  </button>
                ))}
              </div>
              <button
                disabled={pc.status === "ocupado"}
                onClick={() => removePc(pc.id)}
                className="text-red-500/80 disabled:opacity-20 disabled:cursor-not-allowed"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Sessão (iniciar + em andamento)                                          */
/* ---------------------------------------------------------------------- */

function SessaoView({ db, setDb, alertsRef, zeroBeepRef, ctx }) {
  const [pcId, setPcId] = useState("");
  const [gameId, setGameId] = useState("");
  const [priceId, setPriceId] = useState("");
  const [custom, setCustom] = useState(false);
  const [customLabel, setCustomLabel] = useState("");
  const [customMinutes, setCustomMinutes] = useState(30);
  const [customValue, setCustomValue] = useState(0);
  const [client, setClient] = useState("");

  const livrePcs = db.pcs.filter((p) => p.status === "livre");
  const game = db.games.find((g) => g.id === gameId);
  const now = Date.now();

  const myOpenCaixa = (db.cashRegisters || []).find((c) => c.userId === ctx.currentUser.id && c.status === "aberto");
  const caixaRequired = !ctx.isAdmin && !myOpenCaixa;

  const resetForm = () => { setPcId(""); setGameId(""); setPriceId(""); setCustom(false); setCustomLabel(""); setCustomValue(0); setClient(""); };

  const clearRefs = (sessionId) => {
    if (alertsRef.current[sessionId]) delete alertsRef.current[sessionId];
    if (zeroBeepRef.current[sessionId]) delete zeroBeepRef.current[sessionId];
  };

  const startSession = () => {
    if (!pcId || !gameId || caixaRequired) return;
    let label, minutes, value;
    if (custom) {
      label = customLabel.trim() || `${customMinutes} min`;
      minutes = Number(customMinutes) || 1;
      value = Number(customValue) || 0;
    } else {
      const price = game?.prices.find((pr) => pr.id === priceId);
      if (!price) return;
      label = price.label; minutes = price.minutes; value = price.value;
    }
    const start = Date.now();
    const sessionId = genId();
    const pc = db.pcs.find((p) => p.id === pcId);
    const session = {
      id: sessionId, gameId, gameName: game.name, priceLabel: label, minutes, value, client: client.trim(),
      startTime: start, endTime: start + minutes * 60000, userId: ctx.currentUser.id, userName: ctx.currentUser.name,
    };
    const historyEntry = {
      id: genId(), pcId, pcName: pc.name, gameId, gameName: game.name, client: client.trim(), priceLabel: label,
      value, minutes, timestamp: start, type: "inicio", userId: ctx.currentUser.id, userName: ctx.currentUser.name,
    };
    setDb((prev) => ({
      ...prev,
      pcs: prev.pcs.map((p) => (p.id === pcId ? { ...p, status: "ocupado", session } : p)),
      history: [historyEntry, ...prev.history],
    }));
    ctx.audit("Iniciou uma partida", { pcName: pc.name, gameName: game.name, value, client: client.trim() });
    resetForm();
  };

  const plus15 = (pc) => {
    setDb((prev) => ({
      ...prev,
      pcs: prev.pcs.map((p) => (p.id === pc.id ? { ...p, session: { ...p.session, endTime: p.session.endTime + 15 * 60000 } } : p)),
    }));
    ctx.audit("Adicionou 15 min à partida", { pcName: pc.name, gameName: pc.session.gameName });
    clearRefs(pc.session.id);
  };

  const renovar = (pc) => {
    const s = pc.session;
    const base = Math.max(Date.now(), s.endTime);
    const historyEntry = {
      id: genId(), pcId: pc.id, pcName: pc.name, gameId: s.gameId, gameName: s.gameName, client: s.client,
      priceLabel: s.priceLabel, value: s.value, minutes: s.minutes, timestamp: Date.now(), type: "renovacao",
      userId: ctx.currentUser.id, userName: ctx.currentUser.name,
    };
    setDb((prev) => ({
      ...prev,
      pcs: prev.pcs.map((p) => (p.id === pc.id ? { ...p, session: { ...p.session, endTime: base + s.minutes * 60000 } } : p)),
      history: [historyEntry, ...prev.history],
    }));
    ctx.audit("Renovou partida", { pcName: pc.name, gameName: s.gameName, value: s.value });
    clearRefs(s.id);
  };

  const encerrar = (pc) => {
    clearRefs(pc.session.id);
    setDb((prev) => ({ ...prev, pcs: prev.pcs.map((p) => (p.id === pc.id ? { ...p, status: "livre", session: null } : p)) }));
    ctx.audit("Finalizou uma partida", { pcName: pc.name, gameName: pc.session.gameName });
    ctx.notify("pc_disponivel", `${pc.name} ficou disponível (atendente: ${ctx.currentUser.name}).`);
  };

  const ocupados = db.pcs.filter((p) => p.status === "ocupado" && p.session);

  return (
    <div className="p-4 space-y-5">
      <SectionHeader title="Iniciar sessão" />
      {caixaRequired && (
        <Banner tone="red" icon={Wallet}>Abra seu caixa em <b>Meu caixa</b> antes de iniciar partidas ou vendas.</Banner>
      )}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-3">
        <div>
          <label className="text-xs text-slate-500 mb-1 block">PC</label>
          <Select value={pcId} onChange={(e) => setPcId(e.target.value)} disabled={caixaRequired}>
            <option value="">Selecione um PC livre…</option>
            {livrePcs.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          {livrePcs.length === 0 && <p className="text-[11px] text-amber-400 mt-1">Não há PCs livres agora.</p>}
        </div>
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Jogo</label>
          <Select value={gameId} onChange={(e) => { setGameId(e.target.value); setPriceId(""); }} disabled={caixaRequired}>
            <option value="">Selecione o jogo…</option>
            {db.games.map((g) => <option key={g.id} value={g.id}>{g.icon} {g.name}</option>)}
          </Select>
        </div>
        {game && (
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-slate-500">Tempo / preço</label>
              {ctx.isAdmin && <button onClick={() => setCustom((c) => !c)} className="text-[11px] text-cyan-400">{custom ? "usar tabela" : "personalizar"}</button>}
            </div>
            {!custom ? (
              <div className="grid grid-cols-2 gap-2">
                {game.prices.map((pr) => (
                  <button
                    key={pr.id}
                    disabled={caixaRequired}
                    onClick={() => setPriceId(pr.id)}
                    className={`rounded-xl border px-3 py-2 text-left ${priceId === pr.id ? "border-cyan-500 bg-cyan-500/10" : "border-slate-800"}`}
                  >
                    <div className="text-sm font-medium text-slate-100">{pr.label}</div>
                    <div className="text-xs text-slate-500">{fmtKz(pr.value)}</div>
                  </button>
                ))}
                {game.prices.length === 0 && <p className="text-xs text-slate-500 col-span-2">Este jogo ainda não tem preços. Cadastre em Mais → Jogos e preços.</p>}
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                <TextInput placeholder="Rótulo (ex: 1 partida)" value={customLabel} onChange={(e) => setCustomLabel(e.target.value)} className="col-span-3" />
                <TextInput type="number" placeholder="Minutos" value={customMinutes} onChange={(e) => setCustomMinutes(e.target.value)} />
                <TextInput type="number" placeholder="Valor (Kz)" value={customValue} onChange={(e) => setCustomValue(e.target.value)} className="col-span-2" />
              </div>
            )}
          </div>
        )}
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Cliente (opcional)</label>
          <TextInput placeholder="Nome do cliente" value={client} onChange={(e) => setClient(e.target.value)} disabled={caixaRequired} />
        </div>
        <PrimaryButton
          onClick={startSession}
          disabled={!pcId || !gameId || (!custom && !priceId) || caixaRequired}
          className="w-full flex items-center justify-center gap-2"
        >
          <ArrowRightCircle size={16} /> Registrar jogo e iniciar
        </PrimaryButton>
      </div>

      <div>
        <SectionHeader title="Em andamento" subtitle={`${ocupados.length} sessão(ões) ativa(s)`} />
        {ocupados.length === 0 ? (
          <EmptyState text="Nenhuma sessão em andamento." />
        ) : (
          <div className="space-y-3">
            {ocupados.map((pc) => {
              const s = pc.session;
              const remaining = Math.round((s.endTime - now) / 1000);
              const expired = remaining <= 0;
              const color = expired ? "text-red-400" : remaining <= 60 ? "text-red-300" : remaining <= 300 ? "text-amber-400" : "text-cyan-300";
              return (
                <div key={pc.id} className={`bg-slate-900 border rounded-2xl p-3 space-y-3 ${expired ? "border-red-500/50" : "border-slate-800"}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-slate-100">{pc.name}</div>
                      <div className="text-xs text-slate-500">{s.gameName} · {s.priceLabel} · {fmtKz(s.value)}</div>
                      {s.client && <div className="text-xs text-slate-500">Cliente: {s.client}</div>}
                      <div className="text-[11px] text-cyan-400">Atendente: {s.userName || "—"}</div>
                    </div>
                    <div className={`font-mono text-3xl font-bold tabular-nums ${color} ${expired ? "animate-pulse" : ""}`}>
                      {expired ? "00:00" : fmtCountdown(remaining)}
                    </div>
                  </div>
                  {expired && (
                    <div className="flex items-center gap-1.5 text-xs text-red-400"><AlertTriangle size={13} /> Tempo esgotado</div>
                  )}
                  <div className="flex gap-2">
                    <GhostButton onClick={() => plus15(pc)} className="flex items-center gap-1"><Plus size={13} /> 15 min</GhostButton>
                    <GhostButton onClick={() => renovar(pc)} className="flex items-center gap-1"><RotateCcw size={13} /> Renovar ({fmtKz(s.value)})</GhostButton>
                    <button onClick={() => encerrar(pc)} className="ml-auto flex items-center gap-1 text-xs text-red-400 px-3 py-2">
                      <Square size={13} /> Encerrar
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Histórico                                                                */
/* ---------------------------------------------------------------------- */

function HistoricoView({ db, ctx }) {
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    return db.history
      .filter((h) => ctx.isAdmin || h.userId === ctx.currentUser.id)
      .filter((h) => !term || h.client?.toLowerCase().includes(term) || h.pcName?.toLowerCase().includes(term) || h.gameName?.toLowerCase().includes(term) || h.userName?.toLowerCase().includes(term))
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [db.history, q, ctx.isAdmin, ctx.currentUser.id]);

  const exportExcel = async () => {
    const XLSX = await import("xlsx");
    const data = filtered.map((h) => ({
      Data: fmtDateTime(h.timestamp), PC: h.pcName, Jogo: h.gameName, Cliente: h.client || "-", Atendente: h.userName || "-",
      Tipo: h.type === "inicio" ? "Início" : "Renovação", Tempo: h.priceLabel, "Valor (Kz)": h.value,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Historico");
    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([out], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "historico.xlsx";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    if (ctx.isAdmin) ctx.audit("Exportou relatório", { action: "Histórico" });
  };

  return (
    <div className="p-4 space-y-4">
      <SectionHeader title="Histórico" subtitle={`${filtered.length} registro(s) · imutável`} right={
        ctx.isAdmin ? (
          <button onClick={exportExcel} className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5">
            <Download size={13} /> Excel
          </button>
        ) : null
      } />
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
        <TextInput placeholder="Buscar por cliente, PC, jogo ou atendente…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>
      <div className="space-y-2">
        {filtered.length === 0 && <EmptyState text="Nenhum registro encontrado." />}
        {filtered.map((h) => (
          <div key={h.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-slate-500 font-mono">{fmtDateTime(h.timestamp)}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${h.type === "inicio" ? "border-cyan-500/40 text-cyan-400" : "border-slate-600 text-slate-400"}`}>
                {h.type === "inicio" ? "Início" : "Renovação"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-sm font-semibold text-slate-100">{h.pcName} · {h.gameName}</div>
                <div className="text-xs text-slate-500">{h.priceLabel}{h.client ? ` · ${h.client}` : ""}</div>
                {ctx.isAdmin && <div className="text-[11px] text-cyan-400">Atendente: {h.userName || "—"}</div>}
              </div>
              <div className="font-mono text-sm font-semibold text-emerald-400">{fmtKz(h.value)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Relatórios (admin)                                                       */
/* ---------------------------------------------------------------------- */

function MiniBarChart({ data, height = 220, valueFormatter, horizontal = true }) {
  if (!data || data.length === 0) return <EmptyState text="Sem dados no período selecionado." />;
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        {horizontal ? (
          <BarChart data={data} layout="vertical" margin={{ left: 10, right: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
            <XAxis type="number" stroke="#64748b" fontSize={11} tickFormatter={valueFormatter} />
            <YAxis type="category" dataKey="name" stroke="#64748b" fontSize={11} width={80} />
            <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 8, fontSize: 12 }} formatter={valueFormatter} />
            <Bar dataKey="value" fill="#22d3ee" radius={[0, 6, 6, 0]} />
          </BarChart>
        ) : (
          <BarChart data={data} margin={{ left: -20, right: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
            <YAxis stroke="#64748b" fontSize={11} tickFormatter={valueFormatter} />
            <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 8, fontSize: 12 }} formatter={valueFormatter} />
            <Bar dataKey="value" fill="#a78bfa" radius={[6, 6, 0, 0]} />
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}

function PeriodPicker({ period, setPeriod, range, setRange }) {
  return (
    <div className="space-y-2">
      <div className="flex gap-1.5 flex-wrap">
        {["hoje", "ontem", "semana", "mes", "ano", "custom"].map((p) => (
          <button key={p} onClick={() => setPeriod(p)} className={`flex-1 min-w-[15%] text-xs py-2 rounded-lg border capitalize ${period === p ? "bg-cyan-500/10 border-cyan-500 text-cyan-400" : "border-slate-800 text-slate-500"}`}>
            {p === "mes" ? "Mês" : p === "custom" ? "Período" : p}
          </button>
        ))}
      </div>
      {period === "custom" && (
        <div className="grid grid-cols-2 gap-2">
          <TextInput type="date" value={range.start} onChange={(e) => setRange((r) => ({ ...r, start: e.target.value }))} />
          <TextInput type="date" value={range.end} onChange={(e) => setRange((r) => ({ ...r, end: e.target.value }))} />
        </div>
      )}
    </div>
  );
}

function RelatoriosView({ db, ctx }) {
  const [period, setPeriod] = useState("hoje");
  const [range, setRange] = useState({ start: "", end: "" });
  const sales = (db.sales || []).filter((s) => !s.cancelled);
  const periodPredicate = (ts) => inPeriod(ts, period, range);
  const filtered = useMemo(() => db.history.filter((h) => periodPredicate(h.timestamp)), [db.history, period, range]);
  const filteredSales = useMemo(() => sales.filter((s) => periodPredicate(s.timestamp)), [sales, period, range]);
  const inicios = filtered.filter((h) => h.type === "inicio");

  const stats = useMemo(() => {
    const countBy = (arr, key) => {
      const map = {};
      arr.forEach((i) => { map[i[key]] = (map[i[key]] || 0) + 1; });
      let best = null, bestCount = 0;
      Object.entries(map).forEach(([k, v]) => { if (v > bestCount) { best = k; bestCount = v; } });
      return { best, bestCount };
    };
    const jogoMaisJogado = countBy(inicios, "gameName");
    const pcMaisUsado = countBy(inicios, "pcName");
    const hourMap = {};
    inicios.forEach((h) => { const hr = new Date(h.timestamp).getHours(); hourMap[hr] = (hourMap[hr] || 0) + 1; });
    let peakHour = null, peakCount = 0;
    Object.entries(hourMap).forEach(([h, c]) => { if (c > peakCount) { peakHour = h; peakCount = c; } });

    const revenueByGame = {};
    filtered.forEach((h) => { revenueByGame[h.gameName] = (revenueByGame[h.gameName] || 0) + h.value; });
    const gameChart = Object.entries(revenueByGame).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

    const qtyByProduct = {}, revByProduct = {}, revByCategory = {};
    filteredSales.forEach((s) => {
      qtyByProduct[s.productName] = (qtyByProduct[s.productName] || 0) + s.qty;
      revByProduct[s.productName] = (revByProduct[s.productName] || 0) + s.totalValue;
      revByCategory[s.category] = (revByCategory[s.category] || 0) + s.totalValue;
    });
    const productQtyChart = Object.entries(qtyByProduct).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8);
    const productRevChart = Object.entries(revByProduct).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8);
    const categoryChart = Object.entries(revByCategory).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
    let produtoMaisVendido = "—", maiorQtd = 0;
    Object.entries(qtyByProduct).forEach(([name, qty]) => { if (qty > maiorQtd) { produtoMaisVendido = name; maiorQtd = qty; } });

    const receitaVendas = filteredSales.reduce((s, x) => s + x.totalValue, 0);
    const receitaJogos = filtered.reduce((s, x) => s + x.value, 0);
    const produtosVendidos = filteredSales.reduce((s, x) => s + x.qty, 0);

    const dayEvo = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const label = d.toLocaleDateString("pt-AO", { day: "2-digit", month: "2-digit" });
      const total = sales.filter((s) => new Date(s.timestamp).toDateString() === d.toDateString()).reduce((sum, s) => sum + s.totalValue, 0);
      dayEvo.push({ name: label, value: total });
    }
    const monthEvo = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(); d.setMonth(d.getMonth() - i);
      const label = d.toLocaleDateString("pt-AO", { month: "short", year: "2-digit" });
      const total = sales.filter((s) => { const sd = new Date(s.timestamp); return sd.getMonth() === d.getMonth() && sd.getFullYear() === d.getFullYear(); }).reduce((sum, s) => sum + s.totalValue, 0);
      monthEvo.push({ name: label, value: total });
    }

    return {
      jogoMaisJogado, pcMaisUsado, peakHour, gameChart, productQtyChart, productRevChart, categoryChart,
      produtoMaisVendido, receitaVendas, receitaJogos, produtosVendidos, dayEvo, monthEvo,
      totalRevenue: receitaJogos + receitaVendas,
    };
  }, [filtered, filteredSales, inicios, sales]);

  const exportExcel = async () => {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(filtered.map((h) => ({ Data: fmtDateTime(h.timestamp), PC: h.pcName, Jogo: h.gameName, Atendente: h.userName, Valor: h.value }))), "Jogos");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(filteredSales.map((s) => ({ Data: fmtDateTime(s.timestamp), Produto: s.productName, Qtd: s.qty, Total: s.totalValue, Atendente: s.userName }))), "Vendas");
    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([out], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "relatorio.xlsx";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    ctx.audit("Exportou relatório", { action: "Relatórios" });
  };

  return (
    <div className="p-4 space-y-5">
      <SectionHeader title="Relatórios" right={
        <button onClick={exportExcel} className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5">
          <Download size={13} /> Excel
        </button>
      } />
      <PeriodPicker period={period} setPeriod={setPeriod} range={range} setRange={setRange} />

      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Receita dos jogos" value={fmtKz(stats.receitaJogos)} icon={Gamepad2} accent="text-cyan-400" />
        <StatCard label="Receita das vendas" value={fmtKz(stats.receitaVendas)} icon={ShoppingCart} accent="text-violet-400" />
        <StatCard label="Receita total" value={fmtKz(stats.totalRevenue)} icon={TrendingUp} accent="text-emerald-400" className="col-span-2" />
        <StatCard label="Jogos realizados" value={inicios.length} icon={Gamepad2} />
        <StatCard label="Produtos vendidos" value={stats.produtosVendidos} icon={Boxes} />
        <StatCard label="Jogo mais jogado" value={stats.jogoMaisJogado.best || "—"} icon={Zap} />
        <StatCard label="PC mais usado" value={stats.pcMaisUsado.best || "—"} icon={Monitor} />
        <StatCard label="Produto mais vendido" value={stats.produtoMaisVendido} icon={Tag} />
        <StatCard label="Horário de pico" value={stats.peakHour !== null ? `${stats.peakHour}h` : "—"} icon={CalendarClock} />
      </div>

      <div><SectionHeader title="Receita por jogo" /><MiniBarChart data={stats.gameChart} valueFormatter={fmtKz} /></div>
      <div><SectionHeader title="Receita por produto" /><MiniBarChart data={stats.productRevChart} valueFormatter={fmtKz} /></div>
      <div><SectionHeader title="Receita por categoria" /><MiniBarChart data={stats.categoryChart} valueFormatter={fmtKz} /></div>
      <div><SectionHeader title="Quantidade vendida por produto" /><MiniBarChart data={stats.productQtyChart} valueFormatter={(v) => `${v} un.`} /></div>
      <div><SectionHeader title="Evolução das vendas (7 dias)" /><MiniBarChart data={stats.dayEvo} valueFormatter={fmtKz} horizontal={false} height={200} /></div>
      <div><SectionHeader title="Evolução das vendas (12 meses)" /><MiniBarChart data={stats.monthEvo} valueFormatter={fmtKz} horizontal={false} height={200} /></div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Relatório por atendente (admin)                                          */
/* ---------------------------------------------------------------------- */

function AtendentesReportView({ db, ctx }) {
  const [period, setPeriod] = useState("hoje");
  const [range, setRange] = useState({ start: "", end: "" });
  const predicate = (ts) => inPeriod(ts, period, range);
  const stats = useMemo(() => computeAttendantStats(db, ctx.tenantUsers, predicate), [db, ctx.tenantUsers, period, range]);

  return (
    <div className="space-y-4">
      <SectionHeader title="Relatório por atendente" subtitle="Desempenho individual no período" />
      <PeriodPicker period={period} setPeriod={setPeriod} range={range} setRange={setRange} />
      <div className="space-y-2">
        {stats.length === 0 && <EmptyState text="Nenhum atendente cadastrado." />}
        {stats.map((a) => (
          <div key={a.user.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-100">{a.user.name}</span>
                {!a.user.active && <span className="text-[10px] px-1.5 py-0.5 rounded-full border border-red-500/40 text-red-400">Bloqueado</span>}
              </div>
              <span className="font-mono text-sm font-semibold text-emerald-400">{fmtKz(a.receita)}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
              <div>Entrada: <span className="text-slate-200">{fmtTime(a.entrada)}</span></div>
              <div>Saída: <span className="text-slate-200">{fmtTime(a.saida)}</span></div>
              <div>Jogos registrados: <span className="text-slate-200">{a.jogos}</span></div>
              <div>Produtos vendidos: <span className="text-slate-200">{a.produtos}</span></div>
              <div>Cancelamentos: <span className="text-slate-200">{a.cancelamentos}</span></div>
              <div>Tempo médio/partida: <span className="text-slate-200">{a.tempoMedio ? `${Math.round(a.tempoMedio)} min` : "—"}</span></div>
            </div>
            <p className="text-[10px] text-slate-600">Descontos concedidos: recurso ainda não implementado no sistema de vendas.</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Caixa                                                                    */
/* ---------------------------------------------------------------------- */

function MeuCaixaView({ db, setDb, ctx }) {
  const [initialValue, setInitialValue] = useState("");
  const [informedTotal, setInformedTotal] = useState("");
  const [notes, setNotes] = useState("");

  const myOpen = (db.cashRegisters || []).find((c) => c.userId === ctx.currentUser.id && c.status === "aberto");
  const myHistory = (db.cashRegisters || []).filter((c) => c.userId === ctx.currentUser.id && c.status !== "aberto").sort((a, b) => b.openTime - a.openTime);

  const abrirCaixa = () => {
    const val = Number(initialValue) || 0;
    const reg = { id: genId(), userId: ctx.currentUser.id, userName: ctx.currentUser.name, openTime: Date.now(), closeTime: null, initialValue: val, expectedGames: 0, expectedSales: 0, expectedTotal: 0, informedTotal: null, difference: null, notes: "", status: "aberto" };
    setDb((prev) => ({ ...prev, cashRegisters: [reg, ...(prev.cashRegisters || [])] }));
    ctx.audit("Abriu caixa", { value: val });
    setInitialValue("");
  };

  const fecharCaixa = () => {
    if (!myOpen) return;
    const periodPredicate = (ts) => ts >= myOpen.openTime && ts <= Date.now();
    const expectedGames = db.history.filter((h) => h.userId === ctx.currentUser.id && periodPredicate(h.timestamp)).reduce((s, h) => s + h.value, 0);
    const expectedSales = (db.sales || []).filter((s) => s.userId === ctx.currentUser.id && !s.cancelled && periodPredicate(s.timestamp)).reduce((s, x) => s + x.totalValue, 0);
    const expectedTotal = myOpen.initialValue + expectedGames + expectedSales;
    const informed = Number(informedTotal) || 0;
    const difference = informed - expectedTotal;
    const closeTime = Date.now();
    setDb((prev) => ({
      ...prev,
      cashRegisters: prev.cashRegisters.map((c) => c.id === myOpen.id ? { ...c, closeTime, expectedGames, expectedSales, expectedTotal, informedTotal: informed, difference, notes: notes.trim(), status: "fechado" } : c),
    }));
    ctx.audit("Fechou caixa", { value: informed, action: `diferença ${fmtKz(difference)}` });
    ctx.notify("caixa_fechado", `${ctx.currentUser.name} fechou o caixa. Esperado: ${fmtKz(expectedTotal)} · Informado: ${fmtKz(informed)} · Diferença: ${fmtKz(difference)}.`);
    setInformedTotal(""); setNotes("");
  };

  const liveExpected = myOpen ? myOpen.initialValue
    + db.history.filter((h) => h.userId === ctx.currentUser.id && h.timestamp >= myOpen.openTime).reduce((s, h) => s + h.value, 0)
    + (db.sales || []).filter((s) => s.userId === ctx.currentUser.id && !s.cancelled && s.timestamp >= myOpen.openTime).reduce((s, x) => s + x.totalValue, 0)
    : 0;

  return (
    <div className="p-4 space-y-4">
      <SectionHeader title="Meu caixa" />
      {!myOpen ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
          <div className="text-sm font-medium text-slate-200">Abrir caixa</div>
          <TextInput type="number" placeholder="Valor inicial (Kz)" value={initialValue} onChange={(e) => setInitialValue(e.target.value)} />
          <PrimaryButton onClick={abrirCaixa} className="w-full">Abrir caixa</PrimaryButton>
        </div>
      ) : (
        <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-3 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Aberto às {fmtTime(myOpen.openTime)}</span>
            <span className="text-cyan-400">Em andamento</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <StatCard label="Valor inicial" value={fmtKz(myOpen.initialValue)} />
            <StatCard label="Esperado agora" value={fmtKz(liveExpected)} accent="text-emerald-400" />
          </div>
          <div>
            <label className="text-xs text-slate-500 mb-1 block">Valor contado ao fechar (Kz)</label>
            <TextInput type="number" placeholder="Valor informado" value={informedTotal} onChange={(e) => setInformedTotal(e.target.value)} />
          </div>
          <TextInput placeholder="Observações (opcional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <PrimaryButton onClick={fecharCaixa} className="w-full">Fechar caixa</PrimaryButton>
        </div>
      )}

      <div>
        <SectionHeader title="Histórico de caixas" />
        {myHistory.length === 0 ? <EmptyState text="Nenhum caixa fechado ainda." /> : (
          <div className="space-y-2">
            {myHistory.map((c) => (
              <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{fmtDateTime(c.openTime)} → {fmtDateTime(c.closeTime)}</span>
                  <span className={`px-1.5 py-0.5 rounded-full border text-[10px] ${c.status === "aprovado" ? "border-emerald-500/40 text-emerald-400" : c.status === "rejeitado" ? "border-red-500/40 text-red-400" : "border-amber-500/40 text-amber-400"}`}>
                    {c.status === "aprovado" ? "Aprovado" : c.status === "rejeitado" ? "Rejeitado" : "Aguardando aprovação"}
                  </span>
                </div>
                <div className="text-sm text-slate-200">Esperado {fmtKz(c.expectedTotal)} · Informado {fmtKz(c.informedTotal)}</div>
                <div className={`text-xs ${c.difference === 0 ? "text-slate-500" : c.difference > 0 ? "text-emerald-400" : "text-red-400"}`}>Diferença: {fmtKz(c.difference)}</div>
                {c.notes && <div className="text-[11px] text-slate-500">Obs: {c.notes}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AprovacoesCaixaView({ db, setDb, ctx }) {
  const [q, setQ] = useState("");
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [desc, setDesc] = useState("");
  const [value, setValue] = useState("");
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  const [period, setPeriod] = useState("hoje");

  const all = [...(db.cashRegisters || [])].sort((a, b) => b.openTime - a.openTime).filter((c) => !q || c.userName.toLowerCase().includes(q.toLowerCase()));
  const pending = all.filter((c) => c.status === "fechado");

  const aprovar = (c) => {
    if (!ctx.isAdmin) { ctx.audit("Tentativa de acesso sem permissão", { action: "Aprovar caixa" }); return; }
    setDb((prev) => ({ ...prev, cashRegisters: prev.cashRegisters.map((x) => x.id === c.id ? { ...x, status: "aprovado" } : x) }));
    ctx.audit("Aprovou fechamento de caixa", { action: c.userName, value: c.informedTotal });
  };
  const rejeitar = (c) => {
    if (!ctx.isAdmin) { ctx.audit("Tentativa de acesso sem permissão", { action: "Rejeitar caixa" }); return; }
    setDb((prev) => ({ ...prev, cashRegisters: prev.cashRegisters.map((x) => x.id === c.id ? { ...x, status: "rejeitado" } : x) }));
    ctx.audit("Rejeitou fechamento de caixa", { action: c.userName, value: c.informedTotal });
  };

  const despesasPeriodo = db.expenses.filter((e) => inPeriod(e.timestamp, period));
  const totalDespesas = despesasPeriodo.reduce((s, e) => s + Number(e.value), 0);
  const totalJogos = db.history.filter((h) => inPeriod(h.timestamp, period)).reduce((s, h) => s + h.value, 0);
  const totalVendas = (db.sales || []).filter((s) => !s.cancelled && inPeriod(s.timestamp, period)).reduce((s, v) => s + v.totalValue, 0);
  const lucro = totalJogos + totalVendas - totalDespesas;

  const addExpense = () => {
    if (!desc.trim() || !value) return;
    const entry = { id: genId(), desc: desc.trim(), value: Number(value), category, timestamp: Date.now() };
    setDb((prev) => ({ ...prev, expenses: [entry, ...prev.expenses] }));
    ctx.audit("Registrou despesa", { action: entry.desc, value: entry.value });
    setDesc(""); setValue("");
  };
  const removeExpense = (id) => {
    const e = db.expenses.find((x) => x.id === id);
    setDb((prev) => ({ ...prev, expenses: prev.expenses.filter((x) => x.id !== id) }));
    ctx.audit("Editou cadastro", { action: `Removeu despesa: ${e?.desc}` });
  };

  return (
    <div className="p-4 space-y-5">
      <SectionHeader title="Caixa" subtitle="Aprovações e financeiro" />

      {pending.length > 0 && (
        <Banner tone="amber" icon={Wallet}>{pending.length} fechamento(s) aguardando sua aprovação.</Banner>
      )}

      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
        <TextInput placeholder="Buscar por atendente…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>
      <div className="space-y-2">
        {all.length === 0 && <EmptyState text="Nenhum caixa registado ainda." />}
        {all.map((c) => (
          <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-100">{c.userName}</span>
              <span className={`px-1.5 py-0.5 rounded-full border text-[10px] ${c.status === "aberto" ? "border-cyan-500/40 text-cyan-400" : c.status === "aprovado" ? "border-emerald-500/40 text-emerald-400" : c.status === "rejeitado" ? "border-red-500/40 text-red-400" : "border-amber-500/40 text-amber-400"}`}>
                {c.status === "aberto" ? "Em andamento" : c.status === "fechado" ? "Aguardando aprovação" : c.status === "aprovado" ? "Aprovado" : "Rejeitado"}
              </span>
            </div>
            <div className="text-xs text-slate-500">{fmtDateTime(c.openTime)} → {fmtDateTime(c.closeTime)}</div>
            {c.status !== "aberto" && (
              <>
                <div className="text-xs text-slate-400">Esperado {fmtKz(c.expectedTotal)} · Informado {fmtKz(c.informedTotal)}</div>
                <div className={`text-xs ${c.difference === 0 ? "text-slate-500" : c.difference > 0 ? "text-emerald-400" : "text-red-400"}`}>Diferença: {fmtKz(c.difference)}</div>
              </>
            )}
            {c.notes && <div className="text-[11px] text-slate-500">Obs: {c.notes}</div>}
            {c.status === "fechado" && (
              <div className="flex gap-2 pt-1">
                <GhostButton onClick={() => aprovar(c)} className="flex items-center gap-1 text-emerald-400"><BadgeCheck size={13} /> Aprovar</GhostButton>
                <GhostButton onClick={() => rejeitar(c)} className="flex items-center gap-1 text-red-400"><BadgeX size={13} /> Rejeitar</GhostButton>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="border-t border-slate-800 pt-4 space-y-3">
        <SectionHeader title="Financeiro" right={
          <button onClick={() => setShowExpenseForm((s) => !s)} className="flex items-center gap-1 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5"><Plus size={13} /> Despesa</button>
        } />
        <div className="flex gap-1.5 flex-wrap">
          {["hoje", "ontem", "semana", "mes", "ano"].map((p) => (
            <button key={p} onClick={() => setPeriod(p)} className={`flex-1 min-w-[18%] text-xs py-2 rounded-lg border capitalize ${period === p ? "bg-cyan-500/10 border-cyan-500 text-cyan-400" : "border-slate-800 text-slate-500"}`}>
              {p === "mes" ? "Mês" : p}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2">
          <StatCard label="Entradas" value={fmtKz(totalJogos + totalVendas)} accent="text-emerald-400" />
          <StatCard label="Despesas" value={fmtKz(totalDespesas)} accent="text-red-400" />
          <StatCard label="Lucro" value={fmtKz(lucro)} accent={lucro >= 0 ? "text-cyan-400" : "text-red-400"} />
        </div>
        {showExpenseForm && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
            <TextInput placeholder="Descrição (ex: energia)" value={desc} onChange={(e) => setDesc(e.target.value)} />
            <div className="grid grid-cols-2 gap-2">
              <TextInput type="number" placeholder="Valor (Kz)" value={value} onChange={(e) => setValue(e.target.value)} />
              <Select value={category} onChange={(e) => setCategory(e.target.value)}>
                {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </Select>
            </div>
            <PrimaryButton onClick={addExpense} className="w-full">Adicionar despesa</PrimaryButton>
          </div>
        )}
        <div className="space-y-2">
          {despesasPeriodo.length === 0 ? <EmptyState text="Nenhuma despesa no período." /> : despesasPeriodo.map((e) => (
            <div key={e.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
              <div>
                <div className="text-sm text-slate-100">{e.desc}</div>
                <div className="text-xs text-slate-500">{e.category} · {fmtDateTime(e.timestamp)}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono text-sm text-red-400">-{fmtKz(e.value)}</span>
                <button onClick={() => removeExpense(e.id)} className="text-slate-600"><Trash2 size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Jogos e preços (admin)                                                   */
/* ---------------------------------------------------------------------- */

function JogosView({ db, setDb, ctx }) {
  const [openId, setOpenId] = useState(null);
  const [newGame, setNewGame] = useState({ name: "", category: "", icon: "🎮" });
  const [newPrice, setNewPrice] = useState({});

  const addGame = () => {
    if (!newGame.name.trim()) return;
    const g = { id: genId(), name: newGame.name.trim(), category: newGame.category.trim() || "Geral", icon: newGame.icon || "🎮", prices: [] };
    setDb((prev) => ({ ...prev, games: [...prev.games, g] }));
    ctx.audit("Editou cadastro", { gameName: g.name, action: "Novo jogo" });
    setNewGame({ name: "", category: "", icon: "🎮" });
  };

  const removeGame = (id) => {
    const g = db.games.find((x) => x.id === id);
    setDb((prev) => ({ ...prev, games: prev.games.filter((x) => x.id !== id) }));
    ctx.audit("Editou cadastro", { gameName: g?.name, action: "Removeu jogo" });
  };

  const addPrice = (gameId) => {
    const np = newPrice[gameId];
    if (!np || !np.label || !np.value) return;
    const g = db.games.find((x) => x.id === gameId);
    setDb((prev) => ({
      ...prev,
      games: prev.games.map((x) => x.id === gameId ? { ...x, prices: [...x.prices, { id: genId(), label: np.label, minutes: Number(np.minutes) || 1, value: Number(np.value) }] } : x),
    }));
    ctx.audit("Alterou tempo do jogo", { gameName: g?.name, action: `Novo preço: ${np.label}`, value: Number(np.value) });
    ctx.notify("preco_alterado", `Novo preço adicionado a ${g?.name}: ${np.label} — ${fmtKz(np.value)}.`);
    setNewPrice((p) => ({ ...p, [gameId]: { label: "", minutes: "", value: "" } }));
  };

  const removePrice = (gameId, priceId) => {
    const g = db.games.find((x) => x.id === gameId);
    setDb((prev) => ({
      ...prev,
      games: prev.games.map((x) => x.id === gameId ? { ...x, prices: x.prices.filter((p) => p.id !== priceId) } : x),
    }));
    ctx.audit("Alterou preço", { gameName: g?.name, action: "Removeu tabela de preço" });
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Jogos e preços" subtitle="Toca num jogo para editar os preços" />
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
        <div className="text-sm font-medium text-slate-200">Novo jogo</div>
        <div className="grid grid-cols-4 gap-2">
          <TextInput placeholder="🎮" value={newGame.icon} onChange={(e) => setNewGame((g) => ({ ...g, icon: e.target.value }))} />
          <TextInput placeholder="Nome do jogo" value={newGame.name} onChange={(e) => setNewGame((g) => ({ ...g, name: e.target.value }))} className="col-span-3" />
        </div>
        <TextInput placeholder="Categoria (ex: FPS)" value={newGame.category} onChange={(e) => setNewGame((g) => ({ ...g, category: e.target.value }))} />
        <PrimaryButton onClick={addGame} className="w-full">Adicionar jogo</PrimaryButton>
      </div>

      <div className="space-y-2">
        {db.games.map((g) => {
          const open = openId === g.id;
          const np = newPrice[g.id] || { label: "", minutes: "", value: "" };
          return (
            <div key={g.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <button onClick={() => setOpenId(open ? null : g.id)} className="w-full flex items-center justify-between p-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{g.icon}</span>
                  <div className="text-left">
                    <div className="text-sm font-medium text-slate-100">{g.name}</div>
                    <div className="text-xs text-slate-500">{g.category} · {g.prices.length} preço(s)</div>
                  </div>
                </div>
                {open ? <ChevronUp size={16} className="text-slate-500" /> : <ChevronDown size={16} className="text-slate-500" />}
              </button>
              {open && (
                <div className="px-3 pb-3 space-y-2 border-t border-slate-800 pt-3">
                  {g.prices.map((pr) => (
                    <div key={pr.id} className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-lg px-3 py-2">
                      <div className="text-sm text-slate-200">{pr.label} <span className="text-slate-500 text-xs">({pr.minutes} min)</span></div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-emerald-400">{fmtKz(pr.value)}</span>
                        <button onClick={() => removePrice(g.id, pr.id)} className="text-slate-600"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  ))}
                  <div className="grid grid-cols-4 gap-2 pt-1">
                    <TextInput placeholder="Rótulo" value={np.label} onChange={(e) => setNewPrice((p) => ({ ...p, [g.id]: { ...np, label: e.target.value } }))} className="col-span-2" />
                    <TextInput type="number" placeholder="Min" value={np.minutes} onChange={(e) => setNewPrice((p) => ({ ...p, [g.id]: { ...np, minutes: e.target.value } }))} />
                    <TextInput type="number" placeholder="Kz" value={np.value} onChange={(e) => setNewPrice((p) => ({ ...p, [g.id]: { ...np, value: e.target.value } }))} />
                  </div>
                  <div className="flex gap-2">
                    <GhostButton onClick={() => addPrice(g.id)} className="flex items-center gap-1"><PlusCircle size={13} /> Add preço</GhostButton>
                    <button onClick={() => removeGame(g.id)} className="ml-auto text-xs text-red-400 flex items-center gap-1 px-2"><Trash2 size={13} /> Remover jogo</button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Produtos                                                                 */
/* ---------------------------------------------------------------------- */

function EstoqueReadOnlyView({ db }) {
  const [q, setQ] = useState("");
  const products = (db.products || []).filter((p) => !q || p.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="space-y-3">
      <SectionHeader title="Consultar estoque" />
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
        <TextInput placeholder="Buscar produto…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>
      <div className="space-y-2">
        {products.length === 0 && <EmptyState text="Nenhum produto cadastrado." />}
        {products.map((p) => {
          const low = p.qty > 0 && p.qty <= Number(p.minStock || 0);
          const out = p.qty <= 0;
          return (
            <div key={p.id} className={`bg-slate-900 border rounded-xl p-3 flex items-center justify-between ${out ? "border-red-500/40" : low ? "border-amber-500/40" : "border-slate-800"}`}>
              <div>
                <div className="text-sm font-medium text-slate-100">{p.name}</div>
                <div className="text-xs text-slate-500">{p.category} · {fmtKz(p.salePrice)}/un.</div>
              </div>
              <div className={`font-mono text-lg font-semibold ${out ? "text-red-400" : low ? "text-amber-400" : "text-slate-100"}`}>{p.qty}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ProdutosView({ db, setDb, ctx }) {
  const emptyForm = { name: "", category: PRODUCT_CATEGORIES[0], customCategory: "", qty: "", costPrice: "", salePrice: "", minStock: "", notes: "", status: "ativo" };
  const [q, setQ] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [movingId, setMovingId] = useState(null);
  const [moveType, setMoveType] = useState("entrada");
  const [moveQty, setMoveQty] = useState("");
  const [moveEmployee, setMoveEmployee] = useState("");
  const [showLog, setShowLog] = useState(false);

  const products = db.products || [];
  const movements = db.stockMovements || [];

  const filtered = products.filter((p) => {
    const term = q.trim().toLowerCase();
    return !term || p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term);
  });

  const checkStockAlerts = (p) => {
    if (p.status === "ativo" && p.qty <= 0) ctx.notify("produto_esgotado", `${p.name} está esgotado.`);
    else if (p.status === "ativo" && p.qty <= Number(p.minStock || 0)) ctx.notify("estoque_baixo", `${p.name} está com estoque baixo (${p.qty} un.).`);
  };

  const openNew = () => { setEditingId(null); setForm(emptyForm); setShowForm(true); };
  const openEdit = (p) => {
    setEditingId(p.id);
    const known = PRODUCT_CATEGORIES.includes(p.category);
    setForm({ name: p.name, category: known ? p.category : "Outros", customCategory: known ? "" : p.category, qty: p.qty, costPrice: p.costPrice, salePrice: p.salePrice, minStock: p.minStock, notes: p.notes, status: p.status });
    setShowForm(true);
  };

  const saveProduct = () => {
    if (!form.name.trim() || !form.salePrice) return;
    const category = form.category === "Outros" && form.customCategory.trim() ? form.customCategory.trim() : form.category;
    const newSalePrice = Number(form.salePrice);
    const payload = {
      name: form.name.trim(), category, qty: Number(form.qty) || 0, costPrice: form.costPrice === "" ? "" : Number(form.costPrice),
      salePrice: newSalePrice, minStock: Number(form.minStock) || 0, notes: form.notes.trim(), status: form.status,
    };
    if (editingId) {
      const old = products.find((p) => p.id === editingId);
      setDb((prev) => ({ ...prev, products: prev.products.map((p) => (p.id === editingId ? { ...p, ...payload } : p)) }));
      ctx.audit("Editou cadastro", { productName: payload.name });
      if (old && old.salePrice !== newSalePrice) {
        ctx.audit("Alterou preço", { productName: payload.name, value: newSalePrice, action: `de ${fmtKz(old.salePrice)} para ${fmtKz(newSalePrice)}` });
        ctx.notify("preco_alterado", `Preço de ${payload.name} alterado de ${fmtKz(old.salePrice)} para ${fmtKz(newSalePrice)}.`);
      }
      checkStockAlerts({ ...old, ...payload });
    } else {
      const created = { id: genId(), ...payload };
      setDb((prev) => ({ ...prev, products: [...prev.products, created] }));
      ctx.audit("Editou cadastro", { productName: created.name, action: "Novo produto" });
      checkStockAlerts(created);
    }
    setShowForm(false); setEditingId(null); setForm(emptyForm);
  };

  const removeProduct = (id) => {
    const p = products.find((x) => x.id === id);
    setDb((prev) => ({ ...prev, products: prev.products.filter((x) => x.id !== id) }));
    ctx.audit("Excluiu produto", { productName: p?.name });
  };

  const toggleStatus = (p) => {
    setDb((prev) => ({ ...prev, products: prev.products.map((x) => x.id === p.id ? { ...x, status: x.status === "ativo" ? "inativo" : "ativo" } : x) }));
    ctx.audit("Editou cadastro", { productName: p.name, action: p.status === "ativo" ? "Desativou" : "Ativou" });
  };

  const openMove = (id, type) => { setMovingId(id); setMoveType(type); setMoveQty(""); setMoveEmployee(""); };

  const confirmMove = (product) => {
    const qtyNum = Number(moveQty);
    if (!qtyNum || qtyNum <= 0) return;
    let newQty = product.qty;
    let delta = 0;
    if (moveType === "entrada") { delta = qtyNum; newQty = product.qty + qtyNum; }
    else if (moveType === "ajuste") { delta = qtyNum - product.qty; newQty = Math.max(0, qtyNum); }
    const mov = { id: genId(), productId: product.id, productName: product.name, type: moveType, qty: moveType === "ajuste" ? delta : qtyNum, resultingQty: newQty, employee: moveEmployee.trim(), timestamp: Date.now(), userId: ctx.currentUser.id, userName: ctx.currentUser.name };
    setDb((prev) => ({
      ...prev,
      products: prev.products.map((p) => p.id === product.id ? { ...p, qty: Math.max(0, newQty) } : p),
      stockMovements: [mov, ...prev.stockMovements],
    }));
    ctx.audit(moveType === "entrada" ? "Adicionou estoque" : "Corrigiu estoque", { productName: product.name, quantity: qtyNum });
    checkStockAlerts({ ...product, qty: Math.max(0, newQty) });
    setMovingId(null); setMoveQty(""); setMoveEmployee("");
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Produtos" subtitle={`${products.length} cadastrado(s)`} right={
        <button onClick={openNew} className="flex items-center gap-1 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5"><Plus size={13} /> Novo</button>
      } />

      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
        <TextInput placeholder="Buscar produto ou categoria…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>

      {showForm && (
        <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-3 space-y-2">
          <div className="text-sm font-medium text-slate-200">{editingId ? "Editar produto" : "Novo produto"}</div>
          <TextInput placeholder="Nome do produto" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          <div className="grid grid-cols-2 gap-2">
            <Select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}>
              {PRODUCT_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
            {form.category === "Outros" && (
              <TextInput placeholder="Categoria personalizada" value={form.customCategory} onChange={(e) => setForm((f) => ({ ...f, customCategory: e.target.value }))} />
            )}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] text-slate-500">Qtd. em estoque</label>
              <TextInput type="number" value={form.qty} onChange={(e) => setForm((f) => ({ ...f, qty: e.target.value }))} />
            </div>
            <div>
              <label className="text-[11px] text-slate-500">Estoque mínimo</label>
              <TextInput type="number" value={form.minStock} onChange={(e) => setForm((f) => ({ ...f, minStock: e.target.value }))} />
            </div>
            <div>
              <label className="text-[11px] text-slate-500">Preço de compra (opcional)</label>
              <TextInput type="number" value={form.costPrice} onChange={(e) => setForm((f) => ({ ...f, costPrice: e.target.value }))} />
            </div>
            <div>
              <label className="text-[11px] text-slate-500">Preço de venda</label>
              <TextInput type="number" value={form.salePrice} onChange={(e) => setForm((f) => ({ ...f, salePrice: e.target.value }))} />
            </div>
          </div>
          <TextInput placeholder="Observações (opcional)" value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} />
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Status:</span>
            {["ativo", "inativo"].map((s) => (
              <button key={s} onClick={() => setForm((f) => ({ ...f, status: s }))} className={`text-xs px-2.5 py-1 rounded-lg border capitalize ${form.status === s ? "border-cyan-500 bg-cyan-500/10 text-cyan-400" : "border-slate-800 text-slate-500"}`}>{s}</button>
            ))}
          </div>
          <div className="flex gap-2 pt-1">
            <PrimaryButton onClick={saveProduct} className="flex-1">Salvar</PrimaryButton>
            <GhostButton onClick={() => { setShowForm(false); setEditingId(null); }}>Cancelar</GhostButton>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {filtered.length === 0 && <EmptyState text="Nenhum produto encontrado." />}
        {filtered.map((p) => {
          const low = p.qty > 0 && p.qty <= Number(p.minStock || 0);
          const out = p.qty <= 0;
          return (
            <div key={p.id} className={`bg-slate-900 border rounded-2xl p-3 space-y-2 ${out ? "border-red-500/40" : low ? "border-amber-500/40" : "border-slate-800"}`}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-100">{p.name}</span>
                    {p.status === "inativo" && <span className="text-[10px] px-1.5 py-0.5 rounded-full border border-slate-700 text-slate-500">Inativo</span>}
                  </div>
                  <div className="text-xs text-slate-500">{p.category} · {fmtKz(p.salePrice)} / un.</div>
                </div>
                <div className="text-right">
                  <div className={`font-mono text-lg font-semibold ${out ? "text-red-400" : low ? "text-amber-400" : "text-slate-100"}`}>{p.qty}</div>
                  <div className="text-[10px] text-slate-600">un. em estoque</div>
                </div>
              </div>
              {(out || low) && (
                <div className={`text-[11px] flex items-center gap-1 ${out ? "text-red-400" : "text-amber-400"}`}>
                  {out ? <PackageX size={12} /> : <AlertTriangle size={12} />} {out ? "Produto esgotado" : `Estoque baixo (mín. ${p.minStock})`}
                </div>
              )}
              {movingId === p.id ? (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-2 space-y-2">
                  <div className="flex gap-1.5">
                    {["entrada", "ajuste"].map((t) => (
                      <button key={t} onClick={() => setMoveType(t)} className={`text-[11px] px-2 py-1 rounded-lg border capitalize ${moveType === t ? "border-cyan-500 text-cyan-400 bg-cyan-500/10" : "border-slate-800 text-slate-500"}`}>{t === "entrada" ? "Entrada" : "Ajuste manual"}</button>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <TextInput type="number" placeholder={moveType === "entrada" ? "Quantidade a adicionar" : "Nova quantidade total"} value={moveQty} onChange={(e) => setMoveQty(e.target.value)} />
                    <TextInput placeholder="Funcionário (opcional)" value={moveEmployee} onChange={(e) => setMoveEmployee(e.target.value)} />
                  </div>
                  <div className="flex gap-2">
                    <PrimaryButton onClick={() => confirmMove(p)} className="flex-1">Confirmar</PrimaryButton>
                    <GhostButton onClick={() => setMovingId(null)}>Cancelar</GhostButton>
                  </div>
                </div>
              ) : (
                <div className="flex gap-1.5 flex-wrap">
                  <GhostButton onClick={() => openMove(p.id, "entrada")} className="flex items-center gap-1"><Package size={13} /> Entrada</GhostButton>
                  <GhostButton onClick={() => openMove(p.id, "ajuste")} className="flex items-center gap-1"><SlidersHorizontal size={13} /> Ajustar</GhostButton>
                  <GhostButton onClick={() => openEdit(p)} className="flex items-center gap-1"><Pencil size={13} /> Editar</GhostButton>
                  <button onClick={() => toggleStatus(p)} className="text-[11px] text-slate-400 px-2">{p.status === "ativo" ? "Desativar" : "Ativar"}</button>
                  <button onClick={() => removeProduct(p.id)} className="ml-auto text-red-500/80 px-2"><Trash2 size={15} /></button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div>
        <button onClick={() => setShowLog((s) => !s)} className="flex items-center gap-1.5 text-xs text-slate-400">
          <ClipboardList size={13} /> {showLog ? "Ocultar" : "Ver"} histórico de movimentações {showLog ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
        </button>
        {showLog && (
          <div className="space-y-2 mt-2">
            {movements.length === 0 && <EmptyState text="Nenhuma movimentação registada." />}
            {movements.slice(0, 50).map((m) => (
              <div key={m.id} className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="text-slate-200 font-medium">{m.productName}</div>
                  <div className="text-slate-500">{fmtDateTime(m.timestamp)}{m.userName ? ` · ${m.userName}` : ""}</div>
                </div>
                <div className={`font-mono ${m.type === "entrada" ? "text-emerald-400" : m.type === "saida" ? "text-red-400" : "text-amber-400"}`}>
                  {m.type === "saida" ? "-" : m.qty >= 0 ? "+" : ""}{m.qty} un.
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function NovaVendaView({ db, setDb, ctx }) {
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("1");
  const [confirmedMsg, setConfirmedMsg] = useState("");

  const myOpenCaixa = (db.cashRegisters || []).find((c) => c.userId === ctx.currentUser.id && c.status === "aberto");
  const caixaRequired = !ctx.isAdmin && !myOpenCaixa;

  const products = (db.products || []).filter((p) => p.status === "ativo" && p.qty > 0);
  const product = products.find((p) => p.id === productId);
  const qtyNum = Number(qty) || 0;
  const unitValue = product ? product.salePrice : 0;
  const totalValue = unitValue * qtyNum;
  const overStock = product && qtyNum > product.qty;

  const confirmSale = () => {
    if (!product || qtyNum <= 0 || overStock || caixaRequired) return;
    const sale = { id: genId(), productId: product.id, productName: product.name, category: product.category, qty: qtyNum, unitValue, totalValue, timestamp: Date.now(), userId: ctx.currentUser.id, userName: ctx.currentUser.name, cancelled: false };
    const mov = { id: genId(), productId: product.id, productName: product.name, type: "saida", qty: qtyNum, resultingQty: product.qty - qtyNum, employee: "", timestamp: Date.now(), userId: ctx.currentUser.id, userName: ctx.currentUser.name };
    setDb((prev) => ({
      ...prev,
      products: prev.products.map((p) => p.id === product.id ? { ...p, qty: Math.max(0, p.qty - qtyNum) } : p),
      sales: [sale, ...prev.sales],
      stockMovements: [mov, ...prev.stockMovements],
    }));
    ctx.audit("Registrou venda", { productName: product.name, quantity: qtyNum, value: totalValue });
    const newQty = product.qty - qtyNum;
    if (newQty <= 0) ctx.notify("produto_esgotado", `${product.name} ficou esgotado após a venda.`);
    else if (newQty <= Number(product.minStock || 0)) ctx.notify("estoque_baixo", `${product.name} está com estoque baixo (${newQty} un.).`);
    setConfirmedMsg(`Venda registada: ${qtyNum}x ${product.name} — ${fmtKz(totalValue)}`);
    setProductId(""); setQty("1");
    setTimeout(() => setConfirmedMsg(""), 4000);
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Nova venda" />
      {caixaRequired && <Banner tone="red" icon={Wallet}>Abra seu caixa antes de registrar vendas.</Banner>}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-3">
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Produto</label>
          <Select value={productId} onChange={(e) => { setProductId(e.target.value); setQty("1"); }} disabled={caixaRequired}>
            <option value="">Selecione o produto…</option>
            {products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.qty} un.)</option>)}
          </Select>
          {products.length === 0 && <p className="text-[11px] text-amber-400 mt-1">Nenhum produto disponível para venda.</p>}
        </div>
        <div>
          <label className="text-xs text-slate-500 mb-1 block">Quantidade</label>
          <TextInput type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} disabled={caixaRequired} />
          {overStock && <p className="text-[11px] text-red-400 mt-1">Quantidade maior que o estoque disponível ({product.qty} un.).</p>}
        </div>
        {product && (
          <div className="grid grid-cols-2 gap-2">
            <StatCard label="Valor unitário" value={fmtKz(unitValue)} />
            <StatCard label="Valor total" value={fmtKz(totalValue)} accent="text-emerald-400" />
          </div>
        )}
        <PrimaryButton onClick={confirmSale} disabled={!product || qtyNum <= 0 || overStock || caixaRequired} className="w-full flex items-center justify-center gap-2">
          <ShoppingCart size={16} /> Confirmar venda
        </PrimaryButton>
        {confirmedMsg && <div className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-3 py-2">{confirmedMsg}</div>}
      </div>
    </div>
  );
}

function VendasView({ db, setDb, ctx }) {
  const [date, setDate] = useState("");
  const [productFilter, setProductFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");

  const allSales = (db.sales || []).filter((s) => ctx.isAdmin || s.userId === ctx.currentUser.id);
  const productNames = [...new Set(allSales.map((s) => s.productName))];
  const categories = [...new Set(allSales.map((s) => s.category))];

  const filtered = allSales
    .filter((s) => !date || new Date(s.timestamp).toISOString().slice(0, 10) === date)
    .filter((s) => !productFilter || s.productName === productFilter)
    .filter((s) => !categoryFilter || s.category === categoryFilter)
    .sort((a, b) => b.timestamp - a.timestamp);

  const total = filtered.filter((s) => !s.cancelled).reduce((s, x) => s + x.totalValue, 0);

  const cancelSale = (sale) => {
    if (!ctx.isAdmin) { ctx.audit("Tentativa de acesso sem permissão", { action: "Cancelar venda" }); return; }
    if (sale.cancelled) return;
    const product = db.products.find((p) => p.id === sale.productId);
    const mov = product ? { id: genId(), productId: product.id, productName: product.name, type: "entrada", qty: sale.qty, resultingQty: product.qty + sale.qty, employee: "", timestamp: Date.now(), userId: ctx.currentUser.id, userName: ctx.currentUser.name } : null;
    setDb((prev) => ({
      ...prev,
      sales: prev.sales.map((s) => s.id === sale.id ? { ...s, cancelled: true, cancelledBy: ctx.currentUser.name, cancelledAt: Date.now() } : s),
      products: product ? prev.products.map((p) => p.id === product.id ? { ...p, qty: p.qty + sale.qty } : p) : prev.products,
      stockMovements: mov ? [mov, ...prev.stockMovements] : prev.stockMovements,
    }));
    ctx.audit("Cancelou venda", { productName: sale.productName, quantity: sale.qty, value: sale.totalValue, action: `originalmente registada por ${sale.userName}` });
    ctx.notify("registro_cancelado", `Venda de ${sale.qty}x ${sale.productName} (${sale.userName}) foi cancelada por ${ctx.currentUser.name}.`);
  };

  return (
    <div className="space-y-4">
      <SectionHeader title={ctx.isAdmin ? "Vendas" : "Minhas vendas"} subtitle={`${filtered.length} venda(s) · ${fmtKz(total)}`} />
      <div className="grid grid-cols-3 gap-2">
        <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <Select value={productFilter} onChange={(e) => setProductFilter(e.target.value)}>
          <option value="">Produto</option>
          {productNames.map((n) => <option key={n} value={n}>{n}</option>)}
        </Select>
        <Select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
          <option value="">Categoria</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </Select>
      </div>
      <div className="space-y-2">
        {filtered.length === 0 && <EmptyState text="Nenhuma venda encontrada." />}
        {filtered.map((s) => (
          <div key={s.id} className={`bg-slate-900 border rounded-xl p-3 ${s.cancelled ? "border-red-500/30 opacity-70" : "border-slate-800"}`}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-500 font-mono">{fmtDateTime(s.timestamp)}</span>
              <div className="flex items-center gap-1.5">
                {s.cancelled && <span className="text-[10px] px-1.5 py-0.5 rounded-full border border-red-500/40 text-red-400">Cancelada</span>}
                <span className="text-[10px] px-1.5 py-0.5 rounded-full border border-violet-500/40 text-violet-400">{s.category}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-slate-100">{s.productName}</div>
                <div className="text-xs text-slate-500">{s.qty} un. × {fmtKz(s.unitValue)}{ctx.isAdmin ? ` · ${s.userName || "—"}` : ""}</div>
              </div>
              <div className={`font-mono text-sm font-semibold ${s.cancelled ? "text-slate-500 line-through" : "text-emerald-400"}`}>{fmtKz(s.totalValue)}</div>
            </div>
            {ctx.isAdmin && !s.cancelled && (
              <button onClick={() => cancelSale(s)} className="mt-2 text-[11px] text-red-400 flex items-center gap-1"><X size={12} /> Cancelar venda</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function ReservasView({ db, setDb, ctx }) {
  const [form, setForm] = useState({ pcId: "", client: "", date: "", time: "" });

  const addReservation = () => {
    if (!form.pcId || !form.client.trim() || !form.date || !form.time) return;
    const pc = db.pcs.find((p) => p.id === form.pcId);
    setDb((prev) => ({ ...prev, reservations: [...prev.reservations, { id: genId(), pcId: form.pcId, pcName: pc.name, client: form.client.trim(), date: form.date, time: form.time }] }));
    ctx.audit("Editou cadastro", { pcName: pc.name, action: `Criou reserva para ${form.client.trim()}` });
    setForm({ pcId: "", client: "", date: "", time: "" });
  };

  const removeReservation = (id) => {
    const r = db.reservations.find((x) => x.id === id);
    setDb((prev) => ({ ...prev, reservations: prev.reservations.filter((x) => x.id !== id) }));
    ctx.audit("Editou cadastro", { pcName: r?.pcName, action: `Removeu reserva de ${r?.client}` });
  };

  const sorted = [...db.reservations].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));

  return (
    <div className="space-y-4">
      <SectionHeader title="Reservas" />
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
        <Select value={form.pcId} onChange={(e) => setForm((f) => ({ ...f, pcId: e.target.value }))}>
          <option value="">Selecione o PC…</option>
          {db.pcs.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </Select>
        <TextInput placeholder="Nome do cliente" value={form.client} onChange={(e) => setForm((f) => ({ ...f, client: e.target.value }))} />
        <div className="grid grid-cols-2 gap-2">
          <TextInput type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
          <TextInput type="time" value={form.time} onChange={(e) => setForm((f) => ({ ...f, time: e.target.value }))} />
        </div>
        <PrimaryButton onClick={addReservation} className="w-full">Adicionar reserva</PrimaryButton>
      </div>
      <div className="space-y-2">
        {sorted.length === 0 && <EmptyState text="Nenhuma reserva agendada." />}
        {sorted.map((r) => (
          <div key={r.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
            <div>
              <div className="text-sm text-slate-100">{r.pcName} · {r.client}</div>
              <div className="text-xs text-slate-500">{r.date} às {r.time}</div>
            </div>
            <button onClick={() => removeReservation(r.id)} className="text-slate-600"><Trash2 size={15} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Usuários (admin)                                                         */
/* ---------------------------------------------------------------------- */

function UsuariosView({ ctx }) {
  const emptyForm = { username: "", name: "", password: "" };
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [resettingId, setResettingId] = useState(null);
  const [resetPw, setResetPw] = useState("");

  const accounts = ctx.tenantUsers; // atendentes + o próprio admin, apenas desta casa

  const createUser = async () => {
    setError("");
    if (!form.username.trim() || !form.name.trim() || !form.password) { setError("Preencha todos os campos."); return; }
    if (form.password.length < 4) { setError("A senha deve ter pelo menos 4 caracteres."); return; }
    if (ctx.platform.accounts.some((a) => a.username.toLowerCase() === form.username.trim().toLowerCase())) { setError("Já existe um usuário com esse nome de usuário na plataforma."); return; }
    const hash = await hashPassword(form.password);
    const user = { id: genId(), tenantId: ctx.tenantId, username: form.username.trim(), name: form.name.trim(), role: "atendente", active: true, passwordHash: hash, createdAt: Date.now() };
    ctx.setPlatform((prev) => ({ ...prev, accounts: [...prev.accounts, user] }));
    ctx.audit("Criou usuário", { action: `${user.name} (Atendente) — usuário: ${user.username}` });
    setForm(emptyForm); setShowForm(false);
  };

  const toggleActive = (u) => {
    if (u.id === ctx.currentUser.id) { setError("Você não pode bloquear sua própria conta."); return; }
    setError("");
    ctx.setPlatform((prev) => ({ ...prev, accounts: prev.accounts.map((x) => x.id === u.id ? { ...x, active: !x.active } : x) }));
    ctx.audit(u.active ? "Bloqueou usuário" : "Desbloqueou usuário", { action: u.name });
  };

  const removeUser = (u) => {
    if (u.id === ctx.currentUser.id) { setError("Você não pode excluir sua própria conta."); return; }
    setError("");
    ctx.setPlatform((prev) => ({ ...prev, accounts: prev.accounts.filter((x) => x.id !== u.id) }));
    ctx.audit("Excluiu usuário", { action: u.name });
  };

  const confirmReset = async (u) => {
    if (!resetPw) return;
    const hash = await hashPassword(resetPw);
    ctx.setPlatform((prev) => ({ ...prev, accounts: prev.accounts.map((x) => x.id === u.id ? { ...x, passwordHash: hash } : x) }));
    ctx.audit("Redefiniu senha", { action: u.name });
    setResettingId(null); setResetPw("");
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Usuários" subtitle={`${accounts.length} conta(s) desta casa`} right={
        <button onClick={() => { setShowForm((s) => !s); setError(""); }} className="flex items-center gap-1 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5"><UserPlus size={13} /> Novo atendente</button>
      } />
      {error && <Banner tone="red">{error}</Banner>}
      <Banner tone="cyan" icon={ShieldCheck}>Apenas o administrador pode criar contas de atendente. Após criar, entregue o usuário e a senha ao funcionário.</Banner>

      {showForm && (
        <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-3 space-y-2">
          <div className="text-sm font-medium text-slate-200">Novo atendente</div>
          <TextInput placeholder="Nome completo" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          <TextInput placeholder="Usuário (login)" value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} />
          <TextInput type="password" placeholder="Senha" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
          <div className="flex gap-2 pt-1">
            <PrimaryButton onClick={createUser} className="flex-1">Criar atendente</PrimaryButton>
            <GhostButton onClick={() => setShowForm(false)}>Cancelar</GhostButton>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {accounts.map((u) => (
          <div key={u.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-slate-100 flex items-center gap-1.5">{u.name} {u.id === ctx.currentUser.id && <span className="text-[10px] text-slate-500">(você)</span>}</div>
                <div className="text-xs text-slate-500">@{u.username}</div>
              </div>
              <div className="flex items-center gap-2">
                <RolePill role={u.role} />
                {u.active ? <Unlock size={14} className="text-emerald-400" /> : <Lock size={14} className="text-red-400" />}
              </div>
            </div>
            {u.role === "admin" ? (
              <p className="text-[11px] text-slate-600">Conta de administrador — gerenciada pelo próprio dono via recuperação de senha.</p>
            ) : resettingId === u.id ? (
              <div className="flex gap-2">
                <TextInput type="password" placeholder="Nova senha" value={resetPw} onChange={(e) => setResetPw(e.target.value)} />
                <GhostButton onClick={() => confirmReset(u)}>Salvar</GhostButton>
                <GhostButton onClick={() => setResettingId(null)}>Cancelar</GhostButton>
              </div>
            ) : (
              <div className="flex gap-1.5 flex-wrap">
                <GhostButton onClick={() => toggleActive(u)} className="flex items-center gap-1">{u.active ? <Lock size={12} /> : <Unlock size={12} />} {u.active ? "Bloquear" : "Desbloquear"}</GhostButton>
                <GhostButton onClick={() => { setResettingId(u.id); setResetPw(""); }} className="flex items-center gap-1"><KeyRound size={12} /> Redefinir senha</GhostButton>
                <button onClick={() => removeUser(u)} className="ml-auto text-red-500/80 px-2"><Trash2 size={15} /></button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Auditoria (admin)                                                        */
/* ---------------------------------------------------------------------- */

function AuditoriaView({ db, ctx }) {
  const [q, setQ] = useState("");
  const [roleFilter, setRoleFilter] = useState("");

  const filtered = db.auditLog
    .filter((a) => !roleFilter || a.role === roleFilter)
    .filter((a) => !q || a.userName?.toLowerCase().includes(q.toLowerCase()) || a.action?.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => b.timestamp - a.timestamp);

  const exportExcel = async () => {
    const XLSX = await import("xlsx");
    const data = filtered.map((a) => ({
      Data: fmtDateTime(a.timestamp), Usuário: a.userName, Função: ROLE_LABELS[a.role] || a.role, Ação: a.action,
      PC: a.pcName || "-", Produto: a.productName || "-", Jogo: a.gameName || "-", Valor: a.value ?? "-", Quantidade: a.quantity ?? "-", Dispositivo: a.device || "-",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Auditoria");
    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([out], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const el = document.createElement("a");
    el.href = url; el.download = "auditoria.xlsx";
    document.body.appendChild(el); el.click(); document.body.removeChild(el);
    URL.revokeObjectURL(url);
    ctx.audit("Exportou relatório", { action: "Auditoria" });
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Auditoria" subtitle={`${filtered.length} evento(s) · registro imutável`} right={
        <button onClick={exportExcel} className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 rounded-lg px-2.5 py-1.5"><Download size={13} /> Excel</button>
      } />
      <div className="grid grid-cols-3 gap-2">
        <div className="col-span-2 relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
          <TextInput placeholder="Buscar usuário ou ação…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
        <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
          <option value="">Todas as funções</option>
          <option value="admin">Administrador</option>
          <option value="atendente">Atendente</option>
        </Select>
      </div>
      <div className="space-y-2">
        {filtered.length === 0 && <EmptyState text="Nenhum evento registado." />}
        {filtered.slice(0, 200).map((a) => (
          <div key={a.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-mono">{fmtDateTime(a.timestamp)}</span>
              <RolePill role={a.role} />
            </div>
            <div className="text-sm text-slate-100">{a.userName} — {a.action}</div>
            <div className="text-[11px] text-slate-500 flex flex-wrap gap-x-3">
              {a.pcName && <span>PC: {a.pcName}</span>}
              {a.gameName && <span>Jogo: {a.gameName}</span>}
              {a.productName && <span>Produto: {a.productName}</span>}
              {a.value !== undefined && a.value !== null && <span>Valor: {fmtKz(a.value)}</span>}
              {a.quantity !== undefined && a.quantity !== null && <span>Qtd: {a.quantity}</span>}
              {a.client && <span>Cliente: {a.client}</span>}
              {a.action && a.device && <span>Dispositivo: {a.device}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Notificações (admin)                                                     */
/* ---------------------------------------------------------------------- */

function NotificacoesView({ db, setDb }) {
  const notifs = [...(db.notifications || [])].sort((a, b) => b.timestamp - a.timestamp);
  const markRead = (id) => setDb((prev) => ({ ...prev, notifications: prev.notifications.map((n) => n.id === id ? { ...n, read: true } : n) }));
  const markAllRead = () => setDb((prev) => ({ ...prev, notifications: prev.notifications.map((n) => ({ ...n, read: true })) }));

  const iconFor = (type) => {
    if (type === "preco_alterado") return Tag;
    if (type === "registro_cancelado") return X;
    if (type === "estoque_baixo") return AlertTriangle;
    if (type === "produto_esgotado") return PackageX;
    if (type === "pc_disponivel") return Monitor;
    if (type === "caixa_fechado") return Wallet;
    if (type === "acesso_negado") return ShieldAlert;
    return Bell;
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Notificações" subtitle={`${notifs.filter((n) => !n.read).length} não lida(s)`} right={
        <GhostButton onClick={markAllRead}>Marcar todas como lidas</GhostButton>
      } />
      <div className="space-y-2">
        {notifs.length === 0 && <EmptyState text="Nenhuma notificação." />}
        {notifs.map((n) => {
          const Icon = iconFor(n.type);
          return (
            <button key={n.id} onClick={() => markRead(n.id)} className={`w-full text-left flex items-start gap-2.5 rounded-xl border p-3 ${n.read ? "border-slate-800 bg-slate-900 opacity-60" : "border-cyan-500/30 bg-cyan-500/5"}`}>
              <Icon size={16} className={`mt-0.5 shrink-0 ${n.read ? "text-slate-500" : "text-cyan-400"}`} />
              <div className="flex-1">
                <div className="text-sm text-slate-100">{n.message}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{fmtDateTime(n.timestamp)}</div>
              </div>
              {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Backup (admin)                                                           */
/* ---------------------------------------------------------------------- */

function BackupView({ db, setDb, ctx }) {
  const [backups, setBackups] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const prefix = `lanhouse-backup-${ctx.tenantId}-`;

  const refreshList = async () => {
    try {
      const res = await window.storage.list(prefix, true);
      setBackups((res?.keys || []).sort().reverse());
    } catch (e) { setBackups([]); }
  };

  useEffect(() => { refreshList(); }, [ctx.tenantId]);

  const downloadNow = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `backup-${ctx.currentTenant?.venueName || "casa"}-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    ctx.audit("Exportou relatório", { action: "Backup manual (download)" });
  };

  const restoreFromKey = async (key) => {
    setBusy(true); setMsg("");
    try {
      const res = await window.storage.get(key, true);
      if (res && res.value) {
        const restored = JSON.parse(res.value);
        setDb((prev) => ({ ...prev, ...restored }));
        ctx.audit("Restaurou backup", { action: key });
        setMsg(`Backup "${key}" restaurado com sucesso.`);
      }
    } catch (e) { setMsg("Não foi possível restaurar este backup."); }
    setBusy(false);
  };

  const saveSnapshotNow = async () => {
    setBusy(true);
    const key = `${prefix}${new Date().toISOString().slice(0, 10)}`;
    try {
      await window.storage.set(key, JSON.stringify(db), true);
      await refreshList();
      setMsg("Snapshot de hoje salvo.");
    } catch (e) { setMsg("Falha ao salvar snapshot."); }
    setBusy(false);
  };

  return (
    <div className="space-y-4">
      <SectionHeader title="Backup" subtitle="Backup individual desta casa de jogos" />
      <Banner tone="cyan" icon={Database}>Um snapshot desta casa é salvo automaticamente uma vez por dia. Use "Baixar backup agora" para guardar uma cópia fora do sistema.</Banner>
      <div className="grid grid-cols-2 gap-2">
        <PrimaryButton onClick={downloadNow} className="flex items-center justify-center gap-2"><DownloadCloud size={15} /> Baixar agora</PrimaryButton>
        <GhostButton onClick={saveSnapshotNow} disabled={busy} className="flex items-center justify-center gap-2"><UploadCloud size={13} /> Salvar snapshot</GhostButton>
      </div>
      {msg && <Banner tone="cyan">{msg}</Banner>}
      <div>
        <SectionHeader title="Snapshots disponíveis" />
        {backups.length === 0 ? <EmptyState text="Nenhum snapshot salvo ainda." /> : (
          <div className="space-y-2">
            {backups.map((key) => (
              <div key={key} className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                <span className="text-sm text-slate-200 font-mono">{key.replace(prefix, "")}</span>
                <GhostButton onClick={() => restoreFromKey(key)} disabled={busy}>Restaurar</GhostButton>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Mais                                                                     */
/* ---------------------------------------------------------------------- */

function MaisView({ db, setDb, ctx }) {
  const sections = ctx.isAdmin ? ADMIN_MAIS_SECTIONS : ATENDENTE_MAIS_SECTIONS;
  const [section, setSection] = useState(sections[0].key);

  useEffect(() => { if (!sections.some((s) => s.key === section)) setSection(sections[0].key); }, [ctx.isAdmin]);

  return (
    <div className="p-4 space-y-4">
      <SectionHeader title="Mais" />
      <div className="grid grid-cols-3 gap-2">
        {sections.map((s) => (
          <button key={s.key} onClick={() => setSection(s.key)} className={`flex flex-col items-center gap-1 py-2.5 rounded-xl border text-[11px] ${section === s.key ? "bg-cyan-500/10 border-cyan-500 text-cyan-400" : "border-slate-800 text-slate-500"}`}>
            <s.icon size={16} />
            {s.label}
          </button>
        ))}
      </div>
      {ctx.isAdmin && section === "usuarios" && <UsuariosView ctx={ctx} />}
      {ctx.isAdmin && section === "jogos" && <JogosView db={db} setDb={setDb} ctx={ctx} />}
      {ctx.isAdmin && section === "produtos" && <ProdutosView db={db} setDb={setDb} ctx={ctx} />}
      {section === "vendas" && <VendasView db={db} setDb={setDb} ctx={ctx} />}
      {section === "venda" && <NovaVendaView db={db} setDb={setDb} ctx={ctx} />}
      {section === "estoque" && <EstoqueReadOnlyView db={db} />}
      {section === "reservas" && <ReservasView db={db} setDb={setDb} ctx={ctx} />}
      {ctx.isAdmin && section === "atendentes" && <AtendentesReportView db={db} ctx={ctx} />}
      {ctx.isAdmin && section === "auditoria" && <AuditoriaView db={db} ctx={ctx} />}
      {ctx.isAdmin && section === "notificacoes" && <NotificacoesView db={db} setDb={setDb} />}
      {ctx.isAdmin && section === "backup" && <BackupView db={db} setDb={setDb} ctx={ctx} />}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* Super Administrador (dono do aplicativo)                                 */
/* ---------------------------------------------------------------------- */

function SuperAdminView({ platform, setPlatform, currentUser, onLogout }) {
  const [tab, setTab] = useState("casas");
  const [q, setQ] = useState("");
  const [announcement, setAnnouncement] = useState("");

  const tenants = platform.tenants.filter((t) => !q || t.venueName.toLowerCase().includes(q.toLowerCase()) || t.ownerName.toLowerCase().includes(q.toLowerCase()));
  const totalAccounts = platform.accounts.filter((a) => a.role !== "superadmin").length;
  const activeTenants = platform.tenants.filter((t) => t.active).length;

  const toggleTenant = (t) => {
    setPlatform((prev) => ({ ...prev, tenants: prev.tenants.map((x) => x.id === t.id ? { ...x, active: !x.active } : x) }));
  };

  const postAnnouncement = () => {
    if (!announcement.trim()) return;
    setPlatform((prev) => ({ ...prev, announcements: [{ id: genId(), message: announcement.trim(), timestamp: Date.now(), author: currentUser.name }, ...(prev.announcements || [])] }));
    setAnnouncement("");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col" style={{ fontFamily: "'Inter', ui-sans-serif, system-ui" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap');`}</style>
      <header className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
            <ShieldCheck size={16} className="text-violet-400" />
          </div>
          <span className="font-semibold tracking-tight">Painel Super Admin</span>
        </div>
        <button onClick={onLogout} className="flex items-center gap-1.5 text-xs text-red-400 border border-red-500/30 rounded-lg px-2.5 py-1.5"><LogOut size={13} /> Sair</button>
      </header>
      <main className="flex-1 overflow-y-auto p-4 max-w-md w-full mx-auto space-y-5">
        <div className="grid grid-cols-3 gap-2">
          <StatCard label="Casas cadastradas" value={platform.tenants.length} icon={Layers} />
          <StatCard label="Casas ativas" value={activeTenants} accent="text-emerald-400" icon={CircleDot} />
          <StatCard label="Contas totais" value={totalAccounts} icon={Users} />
        </div>
        <div className="flex gap-1.5">
          {[{ key: "casas", label: "Casas de jogos" }, { key: "avisos", label: "Avisos & suporte" }].map((t) => (
            <button key={t.key} onClick={() => setTab(t.key)} className={`flex-1 text-xs py-2 rounded-lg border ${tab === t.key ? "bg-violet-500/10 border-violet-500 text-violet-400" : "border-slate-800 text-slate-500"}`}>{t.label}</button>
          ))}
        </div>

        {tab === "casas" && (
          <div className="space-y-3">
            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
              <TextInput placeholder="Buscar casa ou administrador…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
            </div>
            {tenants.length === 0 && <EmptyState text="Nenhuma casa de jogos cadastrada ainda." />}
            {tenants.map((t) => {
              const accs = platform.accounts.filter((a) => a.tenantId === t.id);
              return (
                <div key={t.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-slate-100">{t.venueName}</div>
                      <div className="text-xs text-slate-500">Responsável: {t.ownerName} · {t.phone}</div>
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${t.active ? "border-emerald-500/40 text-emerald-400" : "border-red-500/40 text-red-400"}`}>{t.active ? "Ativa" : "Desativada"}</span>
                  </div>
                  <div className="text-xs text-slate-500">Usuário admin: @{accs.find((a) => a.role === "admin")?.username || "—"} · {accs.length} conta(s) · Plano: {t.plan || PLAN_LABEL}</div>
                  <div className="text-[11px] text-slate-600">Criada em {fmtDateTime(t.createdAt)}</div>
                  <GhostButton onClick={() => toggleTenant(t)} className="flex items-center gap-1">
                    {t.active ? <Lock size={12} /> : <Unlock size={12} />} {t.active ? "Desativar casa" : "Ativar casa"}
                  </GhostButton>
                </div>
              );
            })}
          </div>
        )}

        {tab === "avisos" && (
          <div className="space-y-3">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2">
              <div className="text-sm font-medium text-slate-200">Enviar atualização / aviso</div>
              <TextInput placeholder="Mensagem para todos os administradores…" value={announcement} onChange={(e) => setAnnouncement(e.target.value)} />
              <PrimaryButton onClick={postAnnouncement} className="w-full">Publicar aviso</PrimaryButton>
            </div>
            <div className="space-y-2">
              {(platform.announcements || []).length === 0 && <EmptyState text="Nenhum aviso publicado ainda." />}
              {(platform.announcements || []).map((a) => (
                <div key={a.id} className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                  <div className="text-sm text-slate-100">{a.message}</div>
                  <div className="text-[11px] text-slate-500 mt-1">{fmtDateTime(a.timestamp)} · {a.author}</div>
                </div>
              ))}
            </div>
            <Banner tone="cyan" icon={ShieldCheck}>Para suporte, use os telefones/usuários cadastrados por cada casa na aba "Casas de jogos".</Banner>
          </div>
        )}
      </main>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* App principal                                                            */
/* ---------------------------------------------------------------------- */

function initialPlatform() {
  return { tenants: [], accounts: [], announcements: [] };
}

export default function App() {
  const [platform, setPlatform] = useState(initialPlatform);
  const [platformLoaded, setPlatformLoaded] = useState(false);
  const [db, setDb] = useState(initialDb);
  const [tenantLoaded, setTenantLoaded] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [tab, setTab] = useState("painel");
  const [, setTick] = useState(0);
  const [showNotifs, setShowNotifs] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const dbRef = useRef(db);
  const platformRef = useRef(platform);
  const alertsRef = useRef({});
  const zeroBeepRef = useRef({});
  const lastActivityRef = useRef(Date.now());
  const notifCountRef = useRef(0);

  useEffect(() => { dbRef.current = db; }, [db]);
  useEffect(() => { platformRef.current = platform; }, [platform]);

  const loadTenantData = async (tenantId) => {
    let tenantDb = initialDb();
    try {
      const res = await window.storage.get(`lanhouse-tenant-${tenantId}`, true);
      if (res && res.value) tenantDb = { ...initialDb(), ...JSON.parse(res.value) };
    } catch (e) { /* casa nova, sem dados ainda */ }
    return tenantDb;
  };

  // carregar diretório da plataforma + sessão persistida
  useEffect(() => {
    (async () => {
      let loadedPlatform = null;
      try {
        const res = await window.storage.get("lanhouse-platform", true);
        if (res && res.value) loadedPlatform = JSON.parse(res.value);
      } catch (e) { /* primeira execução */ }
      let finalPlatform = loadedPlatform ? { ...initialPlatform(), ...loadedPlatform } : initialPlatform();
      if (!finalPlatform.accounts || finalPlatform.accounts.length === 0 || !finalPlatform.accounts.some((a) => a.role === "superadmin")) {
        const hash = await hashPassword(DEFAULT_SUPERADMIN_PASSWORD);
        finalPlatform = {
          ...finalPlatform,
          accounts: [...(finalPlatform.accounts || []), { id: genId(), tenantId: null, username: DEFAULT_SUPERADMIN_USERNAME, name: "Super Administrador", role: "superadmin", active: true, passwordHash: hash, createdAt: Date.now() }],
        };
        await window.storage.set("lanhouse-platform", JSON.stringify(finalPlatform), true).catch(() => {});
      }
      setPlatform(finalPlatform);
      setPlatformLoaded(true);

      try {
        const sres = await window.storage.get("lanhouse-session", false);
        if (sres && sres.value) {
          const session = JSON.parse(sres.value);
          if (session && session.accountId && Date.now() - session.lastActivity < INACTIVITY_LIMIT_MS) {
            const u = finalPlatform.accounts.find((x) => x.id === session.accountId);
            if (u && u.active) {
              lastActivityRef.current = Date.now();
              if (u.role === "superadmin") {
                setCurrentUser(u);
              } else {
                const tenant = finalPlatform.tenants.find((t) => t.id === u.tenantId);
                if (tenant && tenant.active) {
                  const tenantDb = await loadTenantData(u.tenantId);
                  setDb(tenantDb);
                  setTenantLoaded(true);
                  setCurrentUser(u);
                }
              }
            }
          }
        }
      } catch (e) { /* sem sessão anterior */ }
    })();
  }, []);

  // salvar dados da casa (com debounce)
  useEffect(() => {
    if (!tenantLoaded || !currentUser || currentUser.role === "superadmin") return;
    const t = setTimeout(() => {
      window.storage.set(`lanhouse-tenant-${currentUser.tenantId}`, JSON.stringify(db), true).catch(() => {});
    }, 400);
    return () => clearTimeout(t);
  }, [db, tenantLoaded, currentUser]);

  // salvar diretório da plataforma (com debounce)
  useEffect(() => {
    if (!platformLoaded) return;
    const t = setTimeout(() => {
      window.storage.set("lanhouse-platform", JSON.stringify(platform), true).catch(() => {});
    }, 400);
    return () => clearTimeout(t);
  }, [platform, platformLoaded]);

  // backup automático diário por casa
  useEffect(() => {
    if (!tenantLoaded || !currentUser || currentUser.role === "superadmin") return;
    const today = new Date().toISOString().slice(0, 10);
    if (db.lastBackupDate === today) return;
    (async () => {
      try {
        await window.storage.set(`lanhouse-backup-${currentUser.tenantId}-${today}`, JSON.stringify(db), true);
        setDb((prev) => ({ ...prev, lastBackupDate: today }));
      } catch (e) { /* ignora falha de backup */ }
    })();
  }, [tenantLoaded, currentUser, db.lastBackupDate]);

  // rastrear atividade do usuário
  useEffect(() => {
    const bump = () => { lastActivityRef.current = Date.now(); };
    window.addEventListener("click", bump);
    window.addEventListener("keydown", bump);
    window.addEventListener("touchstart", bump);
    return () => {
      window.removeEventListener("click", bump);
      window.removeEventListener("keydown", bump);
      window.removeEventListener("touchstart", bump);
    };
  }, []);

  const audit = (action, extra = {}) => {
    if (!currentUser || currentUser.role === "superadmin") return;
    setDb((prev) => ({
      ...prev,
      auditLog: [{ id: genId(), timestamp: Date.now(), userId: currentUser.id, userName: currentUser.name, role: currentUser.role, action, device: getDeviceInfo(), ...extra }, ...prev.auditLog],
    }));
  };
  const notify = (type, message) => {
    setDb((prev) => ({ ...prev, notifications: [{ id: genId(), timestamp: Date.now(), type, message, read: false }, ...prev.notifications] }));
  };

  const handleLogin = async (user) => {
    lastActivityRef.current = Date.now();
    window.storage.set("lanhouse-session", JSON.stringify({ accountId: user.id, lastActivity: Date.now() }), false).catch(() => {});
    if (user.role === "superadmin") {
      setCurrentUser(user);
      return;
    }
    const tenantDb = await loadTenantData(user.tenantId);
    setDb({ ...tenantDb, auditLog: [{ id: genId(), timestamp: Date.now(), userId: user.id, userName: user.name, role: user.role, action: "Fez login", device: getDeviceInfo() }, ...tenantDb.auditLog] });
    setTenantLoaded(true);
    setCurrentUser(user);
    setTab("painel");
  };

  const handleSignup = async ({ adminName, venueName, phone, username, password }) => {
    const tenantId = genId();
    const recoveryCode = generateRecoveryCode();
    const [passwordHash, recoveryCodeHash] = await Promise.all([hashPassword(password), hashPassword(recoveryCode)]);
    const tenant = { id: tenantId, venueName, ownerName: adminName, phone, createdAt: Date.now(), active: true, plan: PLAN_LABEL };
    const account = { id: genId(), tenantId, username, name: adminName, role: "admin", active: true, passwordHash, recoveryCodeHash, createdAt: Date.now() };
    setPlatform((prev) => ({ ...prev, tenants: [...prev.tenants, tenant], accounts: [...prev.accounts, account] }));
    try { await window.storage.set(`lanhouse-tenant-${tenantId}`, JSON.stringify(initialDb()), true); } catch (e) { /* será criado no primeiro save */ }
    return recoveryCode;
  };

  const handleForgotSubmit = async (username, code, newPassword) => {
    const account = platformRef.current.accounts.find((a) => a.role === "admin" && a.username.toLowerCase() === username.toLowerCase());
    if (!account || !account.recoveryCodeHash) return false;
    const codeHash = await hashPassword(code);
    if (codeHash !== account.recoveryCodeHash) return false;
    const passwordHash = await hashPassword(newPassword);
    setPlatform((prev) => ({ ...prev, accounts: prev.accounts.map((a) => a.id === account.id ? { ...a, passwordHash } : a) }));
    return true;
  };

  const handleLogout = (expired = false) => {
    if (currentUser && currentUser.role !== "superadmin") {
      setDb((prev) => ({ ...prev, auditLog: [{ id: genId(), timestamp: Date.now(), userId: currentUser.id, userName: currentUser.name, role: currentUser.role, action: expired ? "Logout automático (sessão expirada)" : "Fez logout", device: getDeviceInfo() }, ...prev.auditLog] }));
    }
    setCurrentUser(null);
    setTenantLoaded(false);
    setDb(initialDb());
    window.storage.delete("lanhouse-session", false).catch(() => {});
    setTab("painel");
    setShowUserMenu(false);
  };

  // inatividade -> logout automático
  useEffect(() => {
    if (!currentUser) return;
    const iv = setInterval(() => {
      if (Date.now() - lastActivityRef.current > INACTIVITY_LIMIT_MS) {
        handleLogout(true);
      } else {
        window.storage.set("lanhouse-session", JSON.stringify({ accountId: currentUser.id, lastActivity: lastActivityRef.current }), false).catch(() => {});
      }
    }, 15000);
    return () => clearInterval(iv);
  }, [currentUser]);

  // relógio + alarmes sonoros + som de notificação nova (admin)
  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
      const now = Date.now();
      dbRef.current.pcs.forEach((pc) => {
        if (pc.status === "ocupado" && pc.session) {
          const s = pc.session;
          const remaining = Math.round((s.endTime - now) / 1000);
          if (!alertsRef.current[s.id]) alertsRef.current[s.id] = new Set();
          const fired = alertsRef.current[s.id];
          if (remaining <= 600 && remaining > 300 && !fired.has("10")) { fired.add("10"); playBeep("warn"); }
          if (remaining <= 300 && remaining > 60 && !fired.has("5")) { fired.add("5"); playBeep("warn"); }
          if (remaining <= 60 && remaining > 0 && !fired.has("1")) { fired.add("1"); playBeep("urgent"); }
          if (remaining <= 0) {
            const last = zeroBeepRef.current[s.id] || 0;
            if (now - last > 4000) { zeroBeepRef.current[s.id] = now; playBeep("alarm"); }
          }
        }
      });
      const unread = (dbRef.current.notifications || []).filter((n) => !n.read).length;
      if (unread > notifCountRef.current) playBeep("notif");
      notifCountRef.current = unread;
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!platformLoaded) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-500 text-sm">Carregando…</div>
    );
  }

  if (!currentUser) {
    return <AuthScreen platform={platform} onLogin={handleLogin} onSignup={handleSignup} onForgotSubmit={handleForgotSubmit} />;
  }

  if (currentUser.role === "superadmin") {
    return <SuperAdminView platform={platform} setPlatform={setPlatform} currentUser={currentUser} onLogout={() => handleLogout(false)} />;
  }

  if (!tenantLoaded) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-500 text-sm">Carregando dados da casa…</div>
    );
  }

  const isAdmin = currentUser.role === "admin";
  const currentTenant = platform.tenants.find((t) => t.id === currentUser.tenantId) || null;
  const tenantUsers = platform.accounts.filter((a) => a.tenantId === currentUser.tenantId);
  const ctx = { currentUser, isAdmin, isSuperAdmin: false, audit, notify, tenantId: currentUser.tenantId, currentTenant, tenantUsers, platform, setPlatform };
  const tabsForRole = isAdmin ? ADMIN_TABS : ATENDENTE_TABS;
  const unreadNotifs = (db.notifications || []).filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col" style={{ fontFamily: "'Inter', ui-sans-serif, system-ui" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap');
        .font-mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
      `}</style>

      <header className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center">
            <Gamepad2 size={16} className="text-cyan-400" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-semibold tracking-tight text-sm">{currentTenant?.venueName || "LAN Manager"}</span>
            <span className="text-[10px] text-slate-500">LAN Manager · {PLAN_LABEL}</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {isAdmin && (
            <button onClick={() => { setShowNotifs((s) => !s); setShowUserMenu(false); }} className="relative text-slate-400">
              <Bell size={18} />
              {unreadNotifs > 0 && <span className="absolute -top-1.5 -right-1.5 bg-cyan-500 text-slate-950 text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">{unreadNotifs > 9 ? "9+" : unreadNotifs}</span>}
            </button>
          )}
          <button onClick={() => { setShowUserMenu((s) => !s); setShowNotifs(false); }} className="flex items-center gap-1.5">
            <span className="text-xs text-slate-300 hidden xs:inline">{currentUser.name}</span>
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[11px] font-semibold text-slate-300">
              {currentUser.name.slice(0, 1).toUpperCase()}
            </div>
          </button>
        </div>

        {showNotifs && isAdmin && (
          <div className="absolute right-4 top-14 w-80 max-w-[90vw] bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-3 space-y-2 max-h-96 overflow-y-auto">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-200">Notificações</span>
              <button onClick={() => setShowNotifs(false)} className="text-slate-500"><X size={15} /></button>
            </div>
            {(db.notifications || []).slice(0, 8).length === 0 ? (
              <EmptyState text="Nenhuma notificação." />
            ) : (
              [...db.notifications].sort((a, b) => b.timestamp - a.timestamp).slice(0, 8).map((n) => (
                <div key={n.id} className={`text-xs rounded-lg p-2 border ${n.read ? "border-slate-800 text-slate-500" : "border-cyan-500/30 text-slate-200 bg-cyan-500/5"}`}>
                  {n.message}
                  <div className="text-[10px] text-slate-600 mt-0.5">{fmtDateTime(n.timestamp)}</div>
                </div>
              ))
            )}
            <button onClick={() => { setShowNotifs(false); setTab("mais"); }} className="text-[11px] text-cyan-400 w-full text-center pt-1">Ver todas</button>
          </div>
        )}

        {showUserMenu && (
          <div className="absolute right-4 top-14 w-56 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-3 space-y-2">
            <div className="text-sm font-medium text-slate-100">{currentUser.name}</div>
            <RolePill role={currentUser.role} />
            <div className="text-[11px] text-slate-500">{currentTenant?.venueName}</div>
            <button onClick={() => handleLogout(false)} className="w-full flex items-center gap-2 text-xs text-red-400 border border-red-500/30 rounded-lg px-3 py-2 mt-2">
              <LogOut size={13} /> Sair
            </button>
          </div>
        )}
      </header>

      {(platform.announcements || []).length > 0 && isAdmin && (
        <div className="max-w-md w-full mx-auto px-4 pt-3">
          <Banner tone="cyan" icon={Bell}>{platform.announcements[0].message}</Banner>
        </div>
      )}

      <main className="flex-1 overflow-y-auto pb-24 max-w-md w-full mx-auto">
        {tab === "painel" && <PainelView db={db} goToSessao={() => setTab("sessao")} ctx={ctx} />}
        {tab === "pcs" && <PcsView db={db} setDb={setDb} ctx={ctx} />}
        {tab === "sessao" && <SessaoView db={db} setDb={setDb} alertsRef={alertsRef} zeroBeepRef={zeroBeepRef} ctx={ctx} />}
        {tab === "historico" && <HistoricoView db={db} ctx={ctx} />}
        {tab === "relatorios" && isAdmin && <RelatoriosView db={db} ctx={ctx} />}
        {tab === "caixa" && (isAdmin ? <AprovacoesCaixaView db={db} setDb={setDb} ctx={ctx} /> : <MeuCaixaView db={db} setDb={setDb} ctx={ctx} />)}
        {tab === "mais" && <MaisView db={db} setDb={setDb} ctx={ctx} />}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-slate-950/95 backdrop-blur border-t border-slate-800 max-w-md w-full mx-auto flex">
        {tabsForRole.map((t) => {
          const active = tab === t.key;
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[10px] ${active ? "text-cyan-400" : "text-slate-500"}`}
            >
              <Icon size={17} />
              {t.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
