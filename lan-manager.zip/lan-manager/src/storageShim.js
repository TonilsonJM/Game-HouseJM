// Recria a API "window.storage" (get/set/delete/list) que o componente usa,
// do mesmo jeito que existia dentro do ambiente de Artifacts do Claude.
//
// Estratégia:
// - Chamadas com shared=true (diretório da plataforma, dados de cada casa,
//   backups) vão para uma tabela no Supabase -> assim qualquer navegador ou
//   celular que acesse o site enxerga os mesmos dados.
// - Chamadas com shared=false (apenas a sessão de login) continuam no
//   localStorage -> cada aparelho guarda o próprio login, o que é o
//   comportamento correto (você não quer que logar num celular desconecte o
//   PC da recepção).
//
// Se as variáveis de ambiente do Supabase não estiverem configuradas, o app
// cai automaticamente para localStorage em tudo (funciona, mas sem
// sincronizar entre aparelhos) — assim o projeto nunca quebra, só perde a
// sincronização.

import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase = null;
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
} else {
  // eslint-disable-next-line no-console
  console.warn(
    "[lan-manager] VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY não configuradas. " +
      "Os dados compartilhados vão usar localStorage (não sincronizam entre navegadores/celulares). " +
      "Veja README.md > 'Sincronizar entre dispositivos (Supabase)'."
  );
}

const LOCAL_NS = "lanhouse-app::";
const localKey = (key) => `${LOCAL_NS}${key}`;

function localGet(key) {
  const raw = window.localStorage.getItem(localKey(key));
  return raw === null ? null : raw;
}
function localSet(key, value) {
  window.localStorage.setItem(localKey(key), value);
}
function localDelete(key) {
  const existed = window.localStorage.getItem(localKey(key)) !== null;
  window.localStorage.removeItem(localKey(key));
  return existed;
}
function localList(prefix) {
  const keys = [];
  for (let i = 0; i < window.localStorage.length; i++) {
    const rawKey = window.localStorage.key(i);
    if (!rawKey || !rawKey.startsWith(LOCAL_NS)) continue;
    const bare = rawKey.slice(LOCAL_NS.length);
    if (!prefix || bare.startsWith(prefix)) keys.push(bare);
  }
  return keys;
}

const TABLE = "kv_store";

window.storage = {
  async get(key, shared) {
    if (shared && supabase) {
      const { data, error } = await supabase.from(TABLE).select("value").eq("key", key).maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return { key, value: data.value, shared: true };
    }
    const raw = localGet(key);
    return raw === null ? null : { key, value: raw, shared: !!shared };
  },

  async set(key, value, shared) {
    if (shared && supabase) {
      const { error } = await supabase.from(TABLE).upsert({ key, value, updated_at: new Date().toISOString() });
      if (error) throw error;
      return { key, value, shared: true };
    }
    localSet(key, value);
    return { key, value, shared: !!shared };
  },

  async delete(key, shared) {
    if (shared && supabase) {
      const { error } = await supabase.from(TABLE).delete().eq("key", key);
      if (error) throw error;
      return { key, deleted: true, shared: true };
    }
    const existed = localDelete(key);
    return existed ? { key, deleted: true, shared: !!shared } : null;
  },

  async list(prefix, shared) {
    if (shared && supabase) {
      let query = supabase.from(TABLE).select("key");
      if (prefix) query = query.like("key", `${prefix}%`);
      const { data, error } = await query;
      if (error) throw error;
      return { keys: (data || []).map((r) => r.key), prefix, shared: true };
    }
    return { keys: localList(prefix), prefix, shared: !!shared };
  },
};
