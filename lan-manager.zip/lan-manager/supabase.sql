-- Rode este script no SQL Editor do seu projeto Supabase (Project > SQL Editor > New query).
-- Ele cria a tabela genérica de "chave/valor" usada pelo app para guardar:
--   - o diretório da plataforma (casas de jogos + contas)
--   - os dados de cada casa (PCs, jogos, estoque, vendas, caixa, auditoria...)
--   - os backups diários de cada casa

create table if not exists kv_store (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

-- Habilita Row Level Security (RLS) e libera acesso público de leitura/escrita.
--
-- ATENÇÃO: como o app não usa o sistema de autenticação do Supabase (ele tem
-- seu próprio login de usuário/senha dentro do React), essas políticas abaixo
-- deixam a tabela acessível a qualquer pessoa que tenha a URL e a chave anon
-- do seu projeto (que ficam visíveis no código do site, pois são "públicas"
-- por natureza no Supabase). Ou seja: a separação entre casas de jogos é
-- garantida pela lógica do aplicativo, não por uma regra de banco de dados.
-- Para produção com dados sensíveis de clientes reais, o ideal é evoluir para
-- Supabase Auth + políticas de RLS baseadas em auth.uid().

alter table kv_store enable row level security;

create policy "public read" on kv_store
  for select using (true);

create policy "public insert" on kv_store
  for insert with check (true);

create policy "public update" on kv_store
  for update using (true) with check (true);

create policy "public delete" on kv_store
  for delete using (true);
